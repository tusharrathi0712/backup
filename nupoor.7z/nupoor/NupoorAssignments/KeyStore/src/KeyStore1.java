import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStore.PasswordProtection;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class KeyStore1 {

	public static void main(String[] args) throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException, UnrecoverableEntryException {
		// TODO Auto-generated method stub
		 String keyStoreFile = "C://Users/nupoork/Desktop/javacirecep.keystore";
		 String password  = "nupoor";
		 KeyStore keyStore = createKeyStore(keyStoreFile,password);
		 
		 SecretKey secretKey = KeyGenerator.getInstance("AES").generateKey();
		 System.out.println("stored key :"+secretKey.toString());
		 
		 
		 KeyStore.SecretKeyEntry keyStoreEntry = new KeyStore.SecretKeyEntry(secretKey);
		 PasswordProtection keyPasssword = new PasswordProtection("pw-secret".toCharArray());
		 keyStore.setEntry("mySecretKey", keyStoreEntry, keyPasssword);
		 keyStore.store(new FileOutputStream(keyStoreFile), password.toCharArray());
		 
		 
		 KeyStore.Entry entry = keyStore.getEntry("mySecretKey", keyPasssword);
		 SecretKey keyFound = ((KeyStore.SecretKeyEntry)entry).getSecretKey();
		 System.out.println("found key : "+keyFound);
		 
		 
		 
	}
	
	
	
	private static KeyStore createKeyStore(String f,String password) throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException
	{
			File fl = new File(f);
			KeyStore keyStore = KeyStore.getInstance("JCEKS");
			if(fl.exists())
			{
				keyStore.load(new FileInputStream(f), password.toCharArray());
			}
			else
			{
				keyStore.load(null, null);
				keyStore.store(new FileOutputStream(f), password.toCharArray());
			}
			return keyStore;
	}

}
