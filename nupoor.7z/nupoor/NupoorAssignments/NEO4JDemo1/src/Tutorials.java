import org.neo4j.graphdb.Label;
public enum Tutorials implements Label {
	JAVA,SCALA,SQL,NEO4J;
}
