import org.neo4j.graphdb.RelationshipType;
public enum TutorialRelationships implements RelationshipType{
	JVM_LANGIAGES,NON_JVM_LANGIAGES;
}