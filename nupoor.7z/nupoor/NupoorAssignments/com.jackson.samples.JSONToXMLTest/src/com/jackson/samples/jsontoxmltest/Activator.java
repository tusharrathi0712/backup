package com.jackson.samples.jsontoxmltest;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

import com.jackson.samples.jsontoxml.JsonToXml;

public class Activator implements BundleActivator {

	ServiceReference reference;
	public void start(BundleContext context) throws Exception {
		//System.out.println("Hello World!!");
		reference =context.getServiceReference(JsonToXml.class.getName());
		JsonToXml jsonToXml = (JsonToXml) context.getService(reference);
		jsonToXml.jsonToXml();
	}
	
	public void stop(BundleContext context) throws Exception {
		System.out.println("Goodbye World!!");
	}

}
