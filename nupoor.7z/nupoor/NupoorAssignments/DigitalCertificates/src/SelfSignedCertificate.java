import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.cert.X509Certificate;

import sun.security.x509.CertAndKeyGen;
import sun.security.x509.X500Name;
public class SelfSignedCertificate {
	
	
	
	public static void main(String args[]) throws NoSuchAlgorithmException, NoSuchProviderException
	{
			try {
				CertAndKeyGen keyGen = new CertAndKeyGen("RSA","SHA1WithRSA",null);
				keyGen.generate(1024);
				X509Certificate [] cert = new X509Certificate[1];
				cert[0] = keyGen.getSelfCertificate(new X500Name("CN=Nupoor"), (long)360*24*3600);
				
				System.out.println(cert[0].toString());
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}

}
