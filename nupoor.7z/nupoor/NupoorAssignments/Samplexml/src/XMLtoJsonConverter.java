import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import org.apache.commons.io.IOUtils;

import net.sf.json.JSON;
import net.sf.json.xml.XMLSerializer;

public class XMLtoJsonConverter {
    private static URL url = null;
    private static InputStream inputStream = null;   
    public static void getXMLfromJson() {
        try{
            url = XMLtoJsonConverter.class.getClassLoader().getResource("C://Users/nupoork/Desktop/Sample.xml");
            inputStream = url.openStream();
            String xml = IOUtils.toString(inputStream);
            JSON objJson = new XMLSerializer().readObject(xml);
            System.out.println("JSON data : " + objJson);
        }catch(Exception e){
            e.printStackTrace();
        }finally{
     try {
                if (inputStream != null) {
                    inputStream.close();
                }
                url = null;
            } catch (IOException ex) {}
        }
    }
    public static void main(String[] args) {
        getXMLfromJson();
    }
}
