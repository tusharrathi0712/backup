import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class SampleXml {

	public SampleXml() {
		
	}

private static File file = new File("C://Users/nupoork/Desktop/Sample.xml");
	
	
	
	
	public void readXml() 
	{
		
	}

	public static void xmlToJson() throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilder dBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		Document doc = dBuilder.parse(file);
		System.out.println("Root element : "+doc.getDocumentElement().getNodeName());
		JSONArray jsonArray = null;
		if(doc.hasChildNodes())
		{
			jsonArray = printNodes(doc.getChildNodes());		
			
		}
		System.out.println("JSON Array : "+jsonArray.toString(4));
		JSONObject jo = jsonArray.getJSONObject(0);
	
	}



	private static JSONArray printNodes(NodeList childNodes) {
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		for(int count = 0;count<childNodes.getLength();count++)
		{
			Node tempNode = childNodes.item(count);
			JSONArray tempArray = null;

			//System.out.println("empNode : "+tempNode.getNodeName());
			
			if(tempNode.getNodeType() == Node.ELEMENT_NODE)
			{
				/*if(tempNode.hasAttributes())
				{
					System.out.println("attr : "+tempNode.getAttributes().getNamedItem("emplid"));
					jsonObject.putOpt("emplid", tempNode.getAttributes().getNamedItem("emplid"));
				}
				*/
				if(tempNode.hasChildNodes() && tempNode.getChildNodes().getLength() > 1)
				{
					tempArray = printNodes(tempNode.getChildNodes());
					
					if(jsonObject.has(tempNode.getNodeName()))
					{
						jsonObject.getJSONArray(tempNode.getNodeName()).put(tempArray.getJSONObject(0));
						
					

					}
					else
					{
						
						jsonObject.put(tempNode.getNodeName(), tempArray);
						
					}
					
				}
				else
					jsonObject.put(tempNode.getNodeName(), tempNode.getTextContent());

			}		
			
			
			}
		
		jsonArray.put(jsonObject);
		return jsonArray;
	}

	
	public static void main(String args[]) throws ParserConfigurationException, SAXException, IOException
	{
		System.out.println("main");
		xmlToJson();
	}

	
}
