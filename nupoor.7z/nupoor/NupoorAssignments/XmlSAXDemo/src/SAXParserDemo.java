import java.io.File;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

public class SAXParserDemo {

	public SAXParserDemo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws ParserConfigurationException, SAXException {
		
		File input = new File("data/employees.xml");
		SAXParserFactory factory = SAXParserFactory.newInstance();
		SAXParser saxParser = factory.newSAXParser();
		EmployeeHandler employeeHandler = new EmployeeHandler();
		try {
			saxParser.parse(input, employeeHandler);
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}

}
