import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import de.odysseus.staxon.json.JsonXMLOutputFactory;

public class EmployeeHandler extends DefaultHandler {

	boolean type = false;
	boolean firstName = false;
	boolean lastName = false;
	boolean age = false;
	boolean email = false;

	XMLOutputFactory outp0utFactory;
	XMLStreamWriter writer;
	
	public EmployeeHandler() {
		outp0utFactory= new JsonXMLOutputFactory();
		try {
			writer = outp0utFactory.createXMLStreamWriter(new FileOutputStream("data/EmployeeJson.json"));
		} catch (FileNotFoundException | XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void characters(char[] ch, int start, int len) throws SAXException {
	
		try {
			writer.writeCharacters(new String(ch,start,len));
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

	@Override
	public void endDocument() throws SAXException {
		try {
			writer.writeEndDocument();
			writer.close();

		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void endElement(String arg0, String arg1, String arg2) throws SAXException {

		try {
			writer.writeEndElement();
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void startDocument() throws SAXException {
		try {
			writer.writeStartDocument();
			
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		
		//if(qName.equalsIgnoreCase("Employee"))
		//{
			try {
				writer.writeStartElement(qName);
				if(attributes != null)
				{
					for(int i=0 ; i< attributes.getLength();i++)
					writer.writeAttribute(attributes.getQName(i), attributes.getValue(i));
				}
				
			} catch (XMLStreamException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		//}
	}

	
}
