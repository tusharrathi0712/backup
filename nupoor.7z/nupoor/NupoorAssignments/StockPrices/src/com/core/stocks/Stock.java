package com.core.stocks;
import java.util.ArrayList;
import java.util.List;

public class Stock {

	private List<Integer> stocksInADay;
	private int buy ;
	private int sell;
	public Stock(int stockPrices[]) {
		stocksInADay = new ArrayList<>();
		for(int i=0;i<stockPrices.length;i++)
		stocksInADay.add(stockPrices[i]);
		

	}
	
	public void getBestTime()
	{
		
		 int max_diff = stocksInADay.get(1) - stocksInADay.get(0);
		 buy = 0;
		 sell = 1;
		 
			 
			 for(int i = 0; i < stocksInADay.size(); i++)
			  {
			    for(int j = i+1; j < stocksInADay.size(); j++)
			    {        
			         if(stocksInADay.get(j) - stocksInADay.get(i) > max_diff)   
			         {
			         max_diff = stocksInADay.get(j) - stocksInADay.get(i);
			         buy = i;
			         sell = j;
			    	}
			    }
			    
			  }    
			
		 
		
		
		
		
		   if(buy == sell)
		   {
			   System.out.println("There is no time to make maximum profit.");
		   }
		   else
		   System.out.println("Best time to buy is : "+buy+ "\nBest time ti sell is : "+sell);
		    
		
		

		
	}
	
	
}
