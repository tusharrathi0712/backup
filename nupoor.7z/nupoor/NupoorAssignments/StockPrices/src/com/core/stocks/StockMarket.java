package com.core.stocks;
public class StockMarket {

	public static void main(String args[])
	{
		int[] array = {100, 180, 260, 310, 40, 535, 695};
		if(array.length < 2)
		{
			System.out.println("Stock prices must be given for atleast two time period.");
		}
		else
		{
		Stock stock = new Stock(array);
		stock.getBestTime();
		}
		
	}
}
