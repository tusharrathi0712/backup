package com.osgi.randomservice;

import org.osgi.framework.Bundle;
import org.osgi.framework.ServiceFactory;
import org.osgi.framework.ServiceRegistration;

public class RandomGeneratorFactory implements ServiceFactory{

	private int count = 0;
	@Override
	public Object getService(Bundle bundle, ServiceRegistration register) {
		System.out.println("create object of RandomService for :"+bundle.getSymbolicName());
		count++;
		System.out.println("Number of bundles using service : "+count);
		RandomGenerator randomGenerator = new RandomGenerator();
		return randomGenerator;
	}

	@Override
	public void ungetService(Bundle bundle, ServiceRegistration register, Object service) {
		
		System.out.println("released object of : "+bundle.getSymbolicName());
		count--;
		System.out.println("Number of bundles : "+count);
	}

}
