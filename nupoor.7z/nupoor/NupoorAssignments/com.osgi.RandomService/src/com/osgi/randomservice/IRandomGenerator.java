/**
 * 
 */
package com.osgi.randomservice;

/**
 * @author nupoork
 *
 */
public interface IRandomGenerator {
	
	
	public int generate();
	public int generate(int upperBoud);

}
