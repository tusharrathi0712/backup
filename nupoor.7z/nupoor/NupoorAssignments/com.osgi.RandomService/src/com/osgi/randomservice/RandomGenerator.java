package com.osgi.randomservice;

import java.util.Random;

public class RandomGenerator implements IRandomGenerator{

	
	final Random random;
	
	public RandomGenerator()
	{
		this.random = new Random();
	}
	
	@Override
	public int generate() {
		return this.random.nextInt();
	}

	@Override
	public int generate(int upperBoud) {
		return this.random.nextInt(upperBoud);
	}

}
