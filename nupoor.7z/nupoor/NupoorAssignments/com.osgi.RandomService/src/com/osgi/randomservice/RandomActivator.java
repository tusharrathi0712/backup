package com.osgi.randomservice;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class RandomActivator implements BundleActivator {

	ServiceRegistration serviceRegistrtion;
	public void start(BundleContext context) throws Exception {
		System.out.println("Lets random");
		RandomGeneratorFactory randomGeneratorFactory = new RandomGeneratorFactory();
		serviceRegistrtion = context.registerService(IRandomGenerator.class.getName(), randomGeneratorFactory, null);
		System.out.println("Random services have been registered");
		
	}
	
	
	
	
	
	
	
	public void stop(BundleContext context) throws Exception {
		System.out.println("Goodbye World!!");
		serviceRegistrtion.unregister();
		
	}

}
