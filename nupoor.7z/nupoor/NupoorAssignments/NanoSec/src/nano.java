import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class nano {

	public nano() {
		// TODO Auto-generated constructor stub
	}
	File csvFile = new File("C://Users/nupoork/Desktop/Scale1_Test1_1Study_TestRun1_50cc_10.0.0.4_CPU.log");
	public static long getNanoSeconds(String csvDate) throws ParseException {
		DateFormat formatter = new SimpleDateFormat("HH:mm:ss.SSS");
		Date begin = (Date) formatter.parse(csvDate);
		begin.setYear(new Date().getYear());
		begin.setMonth(new Date().getMonth());
		begin.setDate(new Date().getDate());
		// System.out.println(" Final Date " + begin);
		long milliseconds = begin.getTime();
		// System.out.println("Milliseconds:" + milliseconds);
		// System.out.println(milliseconds * 1000000);
		return milliseconds * 1000000;
	}
	//@SuppressWarnings("null")
	public void  read()
	{
		BufferedReader reader ;
		List<String> queryData = new ArrayList<String>();
		String data;
		
			try {
				reader = new BufferedReader(new FileReader(csvFile));
			 
			String line;
			String []column = new String[5] ;
			int j=1;
			while ((line = reader.readLine()) != null) {
				String fields[]=line.split(",");
				if (fields[0].toString().equals("Elapsed time")) {
					System.out.println(fields[1]);
					for(int i=1;i<fields.length;i++)
					{
						column[j]=new String(fields[i]);
						if(column[j].contains(" "))
						{
							column[j]=column[j].replaceAll("\\s","");
							System.out.println(column[j]);
						}
						j++;
					}
					continue;
				}
				
				data = "";
				long timestampForInflux = getNanoSeconds(fields[0].toString());
				for(int i=1;i<fields.length;i++)
				{
					if(!fields[i].isEmpty())
					{
						if(i==1)
						{
							data = column[i] + fields[i].toString()+column[i+1]+"0"+column[i+2]+"0"+ " " + String.valueOf(timestampForInflux);
						}
						if(i==2)
						{
							data = column[i-1] + "0"+column[i]+fields[i].toString()+column[i+1]+"0"+ " " + String.valueOf(timestampForInflux);
						}
						if(i==3)
						{
							data = column[i-2] +column[i-1]+"0"+column[i]+fields[i].toString()+ " " + String.valueOf(timestampForInflux);
						}
				    //  data = "success=" + fields[i].toString() + " " + String.valueOf(timestampForInflux);
				      System.out.println("transaction data: "+data);
				      queryData.add(data);
					}
				}
				
			}
			for(int i=0;i<queryData.size();i++)
			{
				System.out.println(queryData.get(i));
			}
			}	
			catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
			
	}
	public void sarread()
	{
		BufferedReader reader ;
		List<String> queryData = new ArrayList<String>();
		String data;
		List<String> columns = new ArrayList<String>();
			
				try {
					reader = new BufferedReader(new FileReader(csvFile));
					String line;
				//	String []column = new String[5] ;
					String ip;
					while ((line = reader.readLine()) != null)
					{
						if(!line.contains("Average"))
						{
							
						String fields[] = line.split(" ");
						
						if(fields[0].equalsIgnoreCase("Linux"))
						{
							String ipa = fields[2].replaceAll("\\(", "");
							ipa=ipa.replaceAll("\\)", "");
							ipa=ipa.replaceAll("ip-", "");
							System.err.println(ipa);
							continue;
						}
						else
						{
							
						String tabFields[] = line.trim().split("\\s++");
						
						if(line.contains("AM") || line.contains("PM"))
						{
						String time = tabFields[0]+" "+tabFields[1];
						System.out.println(time);
						if(line.contains("CPU"))
						{
							String usr = tabFields[3].replaceAll("%","");
							columns.add(usr);
							System.out.println(usr);
							columns.add(tabFields[8].replaceAll("%",""));
							System.out.println(tabFields[8]);
							
						}
						}
							
						}
						
						}
					//	System.out.println(tabFields[1]);
						
						
					}
					/*line = reader.readLine();
					System.out.println("line: "+line);
					if((line = reader.readLine()) != null)
					{
						System.out.println("jdgsdh");
						String fields[] = line.split("\\t");
						for(int i=1;i<fields.length;i++)
						{
							columns.add(fields[i]);
							System.out.println(columns.get(i));
						}
						
					}*/
					
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 
	}
	public static void main(String args[])
	{
		
			//long time = getNanoSeconds("01:04:25 PM");
			//System.out.println("time in nanoseconds: "+time);
			nano n = new nano();
			n.sarread();
			
		
	}

}
