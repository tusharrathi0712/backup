
public class SummaryReport {

	

    private static final String[] COLUMNS = {
            "sampler_label",               
            "aggregate_report_count",     
            "average",                     
            "aggregate_report_median",        
            "aggregate_report_90%_line",        
            "aggregate_report_min",     
            "aggregate_report_max",     
            "aggregate_report_error%",      
            "aggregate_report_rate",  
            "aggregate_report_stddev",               
            };

	public SummaryReport() {
		// TODO Auto-generated constructor stub
	}

	
	
}
