
public class Calculator {

	public Calculator() {
		// TODO Auto-generated constructor stub
	}

}
