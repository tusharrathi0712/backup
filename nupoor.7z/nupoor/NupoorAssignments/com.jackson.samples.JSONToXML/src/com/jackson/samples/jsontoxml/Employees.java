package com.jackson.samples.jsontoxml;

import java.util.List;

import javax.xml.bind.annotation.*;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Employees {

	private List Employee;
	private String type;
	private String firstname;
	private String lastname;
	private String email;
	private String age;
	
	
	public List getEmployee() {
		return Employee;
	}
	
	
	@XmlElement
	public void setEmployee(List employee) {
		Employee = employee;
	}
	public String getType() {
		return type;
	}
	
	@XmlElement
	public void setType(String type) {
		this.type = type;
	}
	public String getFirstname() {
		return firstname;
	}
	
	@XmlElement
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	
	@XmlElement
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmail() {
		return email;
	}
	
	
	@XmlElement
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAge() {
		return age;
	}
	
	@XmlElement
	public void setAge(String age) {
		this.age = age;
	}


	@Override
	public String toString() {
		return "Employees [Employee=" + Employee + ", type=" + type + ", firstname=" + firstname + ", lastname="
				+ lastname + ", email=" + email + ", age=" + age + "]";
	}
	

}
