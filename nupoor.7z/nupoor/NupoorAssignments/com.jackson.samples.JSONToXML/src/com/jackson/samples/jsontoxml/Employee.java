package com.jackson.samples.jsontoxml;

import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)

public class Employee {


		
		private String emplid;
		
		
		public String getEmplid() {
			return emplid;
		}

		@XmlAttribute
		public void setEmplid(String emplid) {
			this.emplid = emplid;
		}

		@XmlValue
		public String getNumber() {
			return number;
		}
		
		
		
		
		
		
		
		


		@Override
		public String toString() {
			return "Employee [emplid=" + emplid + ", number=" + number + "]";
		}

		public void setNumber(String number) {
			this.number = number;
		}


		private String number;
}
