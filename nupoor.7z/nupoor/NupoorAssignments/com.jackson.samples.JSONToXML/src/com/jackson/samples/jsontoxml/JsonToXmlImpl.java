package com.jackson.samples.jsontoxml;

import java.beans.XMLEncoder;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature;

import net.sf.json.JSON;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;
import net.sf.json.xml.XMLSerializer;
import org.json.*;



public class JsonToXmlImpl implements JsonToXml {

	
	File file = new File("C://Users/nupoork/Desktop/SampleJson.json");

/*	@Override
	public void jsonToXml() throws FileNotFoundException, IOException {

		String jsonString = new String(Files.readAllBytes(Paths.get("C://Users/nupoork/Desktop/SampleJson.txt")));
		System.out.println(jsonString);
		
	    JSONObject jobj = new JSONObject(jsonString);
	    JSONArray jarr = new JSONArray(jobj.getJSONArray("Employee").toString());
		JSON jsonObject = JSONSerializer.toJSON(jsonString);
		//XMLSerializer xmlSerializer = new XMLSerializer();
		System.out.println(jsonObject.toString());
		
		
		//xmlSerializer.write(jsonObject);
		
	}*/
	
	@Override
	public void jsonToXml() throws IOException {
			
	
		String jsonString = new String(Files.readAllBytes(Paths.get("C://Users/nupoork/Desktop/SampleJson.txt")));
		System.out.println(jsonString);
		
		ObjectMapper jsonMapper = new ObjectMapper();
		Employees e =  jsonMapper.readValue(jsonString, Employees.class);
		
		XmlMapper xmlMapper = new XmlMapper();
		
		xmlMapper.enable(SerializationFeature.INDENT_OUTPUT);
		xmlMapper.configure(Feature.WRITE_XML_DECLARATION, true);
		System.out.println(xmlMapper.writeValueAsString(e));
		
	}

}
