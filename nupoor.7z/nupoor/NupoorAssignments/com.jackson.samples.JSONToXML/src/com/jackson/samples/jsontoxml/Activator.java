package com.jackson.samples.jsontoxml;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class Activator implements BundleActivator {

	
	ServiceRegistration register;
	public void start(BundleContext context) throws Exception {
		JsonToXml jsonToXml = new JsonToXmlImpl();
		context.registerService(JsonToXml.class.getName(), jsonToXml, null);
	}
	
	public void stop(BundleContext context) throws Exception {
	}

}
