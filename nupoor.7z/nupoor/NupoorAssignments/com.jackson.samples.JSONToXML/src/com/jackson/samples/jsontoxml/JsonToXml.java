package com.jackson.samples.jsontoxml;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface JsonToXml {
	
	
	
	public void jsonToXml() throws FileNotFoundException, IOException;

}
