package com.dom.sample.xmltojson;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class XmlToJsonImpl implements XmlToJson {


	public XmlToJsonImpl() {
	}

	@Override
	public String xmlToJson(File file) throws ParserConfigurationException, IOException, SAXException {
		DocumentBuilder dBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		Document doc = dBuilder.parse(file);
		JSONArray jsonArray = null;
		if (doc.hasChildNodes()) {
			jsonArray = printNodes(doc.getChildNodes());

		}
		return jsonArray.toString(4);

	}

	private JSONArray printNodes(NodeList childNodes) {
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		for (int count = 0; count < childNodes.getLength(); count++) {
			Node tempNode = childNodes.item(count);
			JSONArray tempArray = null;

			if (tempNode.getNodeType() == Node.ELEMENT_NODE) {

				if (tempNode.hasChildNodes() && tempNode.getChildNodes().getLength() > 1) {
					tempArray = printNodes(tempNode.getChildNodes());

					if (jsonObject.has(tempNode.getNodeName())) {
						jsonObject.getJSONArray(tempNode.getNodeName()).put(tempArray.getJSONObject(0));

					} else {

						jsonObject.put(tempNode.getNodeName(), tempArray);
					}
				} else
					jsonObject.put(tempNode.getNodeName(), tempNode.getTextContent());

			}

		}
		jsonArray.put(jsonObject);
		return jsonArray;
	}

}
