package com.dom.sample.xmltojson;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import net.sf.json.JSONArray;

public interface XmlToJson {

	public String xmlToJson(File f) throws ParserConfigurationException, SAXException, IOException;

}
