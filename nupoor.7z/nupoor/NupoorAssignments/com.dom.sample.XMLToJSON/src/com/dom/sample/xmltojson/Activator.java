package com.dom.sample.xmltojson;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class Activator implements BundleActivator {

	
	ServiceRegistration register;

	public void start(BundleContext context) throws Exception {
		XmlToJson xmlToJson = new XmlToJsonImpl();
		register = context.registerService(XmlToJson.class.getName(), xmlToJson, null);

	}

	
	public void stop(BundleContext context) throws Exception {
		register.unregister();
	}

}
