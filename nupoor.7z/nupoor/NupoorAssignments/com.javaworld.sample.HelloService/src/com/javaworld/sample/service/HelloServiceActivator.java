package com.javaworld.sample.service;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class HelloServiceActivator implements BundleActivator {

	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#start(org.osgi.framework.BundleContext)
	 */
	
	ServiceRegistration helloServiceRegistration;
	public void start(BundleContext context) throws Exception {
		HelloServiceFactory helloServiceFactory  = new HelloServiceFactory();
		helloServiceRegistration = context.registerService(HelloService.class.getName(),helloServiceFactory, null);
		System.out.println("Hello World from activator!!");
	}
	
	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext context) throws Exception {
		helloServiceRegistration.unregister();
		System.out.println("Goodbye World!!");
	}
	
	


}
