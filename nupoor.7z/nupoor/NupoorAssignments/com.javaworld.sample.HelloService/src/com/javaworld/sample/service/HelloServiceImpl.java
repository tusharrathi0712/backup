package com.javaworld.sample.service;

public class HelloServiceImpl implements HelloService {

	@Override
	public String sayHello() {
		System.out.println("inside hello service impl");
		return "hello service";
	}

}
