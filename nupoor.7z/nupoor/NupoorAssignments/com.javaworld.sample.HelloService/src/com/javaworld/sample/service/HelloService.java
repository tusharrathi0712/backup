package com.javaworld.sample.service;

public interface HelloService {
	

	    public String sayHello();
	

}
