package com.javaworld.sample.service;

public class HelloServiceImpl1 implements HelloService {

	public HelloServiceImpl1() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String sayHello() {
	
		return "from helloserviceImpl 1";
	}

}
