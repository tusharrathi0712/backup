package com.gfk.mri.exception;

public class GfkMriException extends Exception {

	private static final long serialVersionUID = 1L;

	public GfkMriException(String message)
	{
		super(message);
	}

}
