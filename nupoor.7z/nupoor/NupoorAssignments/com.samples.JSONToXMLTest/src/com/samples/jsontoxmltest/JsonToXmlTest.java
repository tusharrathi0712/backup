package com.samples.jsontoxmltest;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.custommonkey.xmlunit.XMLTestCase;
import org.custommonkey.xmlunit.exceptions.ConfigurationException;
import org.json.JSONException;
import org.junit.Test;
import org.xml.sax.SAXException;

import com.samples.jsontoxml.JsonToXml;
import com.samples.jsontoxml.JsonToXmlImpl;

import junit.framework.TestCase;

public class JsonToXmlTest {
	
	
	@Test
	public void jsonToXmlTest() throws IOException
	{
		JsonToXml jsonToXml = new JsonToXmlImpl();
		XMLTestCase xmlTestCase = new XMLTestCase() {
		};
		String xmlString;
		String controlString = new String(Files.readAllBytes(Paths.get("C://Users/nupoork/Desktop/sample11.xml")));
		try {
			xmlString = jsonToXml.jsonToXml();
			System.out.println(xmlString);
			xmlTestCase.assertXMLEqual(controlString, xmlString);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	
	
	
	
}
