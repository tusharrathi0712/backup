package com.filters.samples.xmltest;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

import com.filters.samples.xml.XmlFilter;
import com.filters.samples.xml.XmlFilterImpl;

public class Activator implements BundleActivator {

	public void start(BundleContext context) throws Exception {
		
	}
	
	public void stop(BundleContext context) throws Exception {
		System.out.println("Goodbye World!!");
	}

}
