package com.filters.samples.xmltest;

import com.filters.samples.xml.XmlFilter;
import com.filters.samples.xml.XmlFilterImpl;

import org.junit.Assert;
import org.junit.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XmlFilterTest {

	public XmlFilterTest() {
	}

	XmlFilter xmlFilter = new XmlFilterImpl();
	
	@Test
	public void filterXmlTest()
	{
		String xPathString = "/Employees/Employee[@emplid";
		String eid = "3333";
		Document document = xmlFilter.filterXml(xPathString,eid);
		NodeList nodeList = document.getElementsByTagName("Employee");
		for(int i=0;i<nodeList.getLength();i++)
		{
			Node node = nodeList.item(i);
			Element e = (Element) node;
			if(e.getAttribute("emplid").equals(eid))
			{
				Assert.fail();
			}
			
			
		}
	}
}
