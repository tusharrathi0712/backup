package com.filters.samples.xml;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class Activator implements BundleActivator {

	ServiceRegistration register;
	public void start(BundleContext context) throws Exception {
		XmlFilter xmlFilter = new XmlFilterImpl();
		register = context.registerService(XmlFilter.class.getName(), xmlFilter, null);
	}
	
	
	public void stop(BundleContext context) throws Exception {
		System.out.println("Goodbye World!!");
	}

}
