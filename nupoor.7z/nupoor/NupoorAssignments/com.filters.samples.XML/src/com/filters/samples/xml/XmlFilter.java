package com.filters.samples.xml;

import org.w3c.dom.Document;

public interface XmlFilter {
	
	
	public Document filterXml(String xPathString,String eid);

}
