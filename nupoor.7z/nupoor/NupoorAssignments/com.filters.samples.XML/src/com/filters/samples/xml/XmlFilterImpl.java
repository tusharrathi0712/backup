package com.filters.samples.xml;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class XmlFilterImpl implements XmlFilter {

	@Override
	public Document filterXml(String xPathString,String eid) {

		File file = new File("D://SampleXml.xml");
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
		documentBuilderFactory.setNamespaceAware(true);
		DocumentBuilder documentBuilder;
		Document doc,document = null;
		try {
			documentBuilder = documentBuilderFactory.newDocumentBuilder();
			doc = documentBuilder.parse(file);
			XPathFactory xPathFactory = XPathFactory.newInstance();
			XPath xPath = xPathFactory.newXPath();
			document = getFilteredEmployees(doc, xPath,xPathString,eid);
			// System.out.println("knkn: "+Arrays.toString(list.toArray()));
		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
		}
		return document;

	}

	private Document getFilteredEmployees(Document doc, XPath xPath,String xPathString,String eid) throws ParserConfigurationException {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document document = dBuilder.newDocument();
		Element rootElement = document.createElement("Employees");
		document.appendChild(rootElement);
		try {
			XPathExpression expr = xPath.compile(xPathString+"="+eid+"]");
			Node node = (Node) expr.evaluate(doc, XPathConstants.NODE);
			
			if (node != null) {
				NodeList nodeList = node.getChildNodes();
				NodeList nodeList1 = doc.getElementsByTagName("Employee");

				for (int i = 0; i < nodeList1.getLength() && nodeList1 != null; i++) {
					Node nod = nodeList1.item(i);
					if (nod.getNodeType() == Node.ELEMENT_NODE) {
						Element element = (Element) nod;
						if (!element.getAttribute("emplid").equals(eid)) {
							Element employee = document.createElement(nod.getLocalName());
							rootElement.appendChild(employee);
							Attr attr = document.createAttribute(nod.getAttributes().item(0).getLocalName());
							attr.setValue(element.getAttribute(nod.getAttributes().item(0).getLocalName()));
							employee.setAttributeNode(attr);
							if(nod.hasChildNodes())
							{	
								NodeList childList = nod.getChildNodes();
								for(int j=1;j<childList.getLength();j++)
								{
									if(childList.item(j).getNodeType() == Node.ELEMENT_NODE)
									{
									Element type = document.createElement(childList.item(j).getLocalName());
									type.appendChild(document.createTextNode(element.getElementsByTagName(childList.item(j).getLocalName()).item(0).getTextContent()));
									employee.appendChild(type);
									}
								
								}
							}
						}
					}

				}
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				transformer.setOutputProperty(OutputKeys.INDENT,"yes");

				DOMSource domSource = new DOMSource(document);
				StreamResult streamResult = new StreamResult(new File("D://filteredXml.xml"));
				transformer.transform(domSource, streamResult);
			}
		} catch (XPathExpressionException | TransformerException e) {
			e.printStackTrace();
		}
		return document;

	}


}
