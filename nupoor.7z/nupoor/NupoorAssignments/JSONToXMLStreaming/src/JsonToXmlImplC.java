import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonStructure;
import javax.json.JsonValue;
import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;
import javax.sql.rowset.spi.XmlWriter;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

public class JsonToXmlImplC implements JsonToXml{

	public JsonToXmlImplC() {
		
		
		
	}

	@Override
	public void jsonToXml() throws FileNotFoundException, IOException, XMLStreamException {
			
			//JsonParser jsonParser = Json.createParser(new FileInputStream("data/sample.json"));
			XMLOutputFactory factory = XMLOutputFactory.newInstance();
			XMLStreamWriter writer = factory.createXMLStreamWriter(new FileOutputStream("data/XmlStreaming.xml"));
			JsonReader jsonReader = Json.createReader(new FileInputStream("data/sample.json"));
			Event event;
			
			JsonObject jsonObject = (JsonObject) jsonReader.readObject();
			JsonObject jsonObject1 = null;
			String root = null;
			System.out.println(jsonObject.keySet().size());
			writer.writeStartDocument();
			for(Entry<String,JsonValue> e : jsonObject.entrySet())
			{
				System.out.println(e.getKey().toString());
				jsonObject1 = (JsonObject) jsonObject.get(e.getKey());
				 root = e.getKey();
					writer.writeStartElement(root);

				 for(int j=0;j<jsonObject1.size();j++)
				 {
					 for(Entry<String,JsonValue> e1 : jsonObject1.entrySet())
					 {
						    System.out.println(e1.getKey());
							JsonArray jsonArray = jsonObject1.getJsonArray(e1.getKey());
							Iterator<JsonValue> it = jsonArray.iterator();
							
							for(int i=0; i<jsonArray.size();i++)
							{
								JsonObject jo = jsonArray.getJsonObject(i);
								writer.writeStartElement(e1.getKey());

								for(Entry<String, JsonValue> entry : jo.entrySet())
								{
									System.out.println(entry.getKey());
									writer.writeStartElement(entry.getKey());
									writer.writeCharacters(entry.getValue().toString());
									writer.writeEndElement();
									System.out.println(entry.getValue());
										
								}
								writer.writeEndElement();
							}
					 }
				 }

			}
			
			
			writer.writeEndElement();
			writer.writeEndDocument();
			writer.close();
			
			
			
						

						
	}
	
	public static void main(String args[]) throws FileNotFoundException, IOException, XMLStreamException
	{
		JsonToXml j = new JsonToXmlImplC();
		j.jsonToXml();
	}
	

}
