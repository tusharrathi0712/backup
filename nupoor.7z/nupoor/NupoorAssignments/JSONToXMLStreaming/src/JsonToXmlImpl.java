

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import de.odysseus.staxon.json.JsonXMLInputFactory;

public class JsonToXmlImpl implements JsonToXml {

	

/*	@Override
	public void jsonToXml() throws FileNotFoundException, IOException {

		String jsonString = new String(Files.readAllBytes(Paths.get("C://Users/nupoork/Desktop/SampleJson.txt")));
		System.out.println(jsonString);
		
	    JSONObject jobj = new JSONObject(jsonString);
	    JSONArray jarr = new JSONArray(jobj.getJSONArray("Employee").toString());
		JSON jsonObject = JSONSerializer.toJSON(jsonString);
		//XMLSerializer xmlSerializer = new XMLSerializer();
		System.out.println(jsonObject.toString());
		
		
		//xmlSerializer.write(jsonObject);
		
	}*/
	
	@Override
	public void jsonToXml() throws IOException, XMLStreamException {
			
	
		String jsonString = new String(Files.readAllBytes(Paths.get("data/sample.json")));
		System.out.println(jsonString);
		StringReader json = new StringReader(jsonString);
	
		XMLInputFactory factory = new JsonXMLInputFactory();
		
		XMLStreamReader reader = factory.createXMLStreamReader(json);
		XMLOutputFactory factory1 = XMLOutputFactory.newInstance();
	
		XMLStreamWriter writer = factory1.createXMLStreamWriter(new FileOutputStream("data/XmlStreaming.xml"));
		if(reader.hasNext())
		{
			writer.writeStartDocument();
			reader.nextTag();
			while(reader.getEventType() != XMLStreamConstants.END_DOCUMENT)
			{
			//System.out.println(reader.getLocalName());
			if(reader.isStartElement())
			{
			writer.writeStartElement(reader.getLocalName());
			}
			if(reader.isCharacters())
			{
				if(reader.hasText())
				writer.writeCharacters(reader.getText());

			}
			if(reader.isEndElement())
			{
				writer.writeEndElement();
			}
			reader.next();
			
			}
			writer.writeEndDocument();
			writer.close();
		}
		
		
	}
	
}
	
	

