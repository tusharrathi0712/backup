

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.stream.XMLStreamException;

public interface JsonToXml {
	
	
	
	public void jsonToXml() throws FileNotFoundException, IOException, XMLStreamException;


}
