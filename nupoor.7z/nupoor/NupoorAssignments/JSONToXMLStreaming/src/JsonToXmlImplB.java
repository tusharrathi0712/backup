import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.json.Json;
import javax.json.JsonReader;
import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

public class JsonToXmlImplB implements JsonToXml{

	public JsonToXmlImplB() {
		
		
		
	}
	String element;
	int cnt,cnt1;
	@Override
	public void jsonToXml() throws FileNotFoundException, IOException, XMLStreamException {
			
			JsonParser jsonParser = Json.createParser(new FileInputStream("data/sample.json"));
			XMLOutputFactory factory = XMLOutputFactory.newInstance();
			XMLStreamWriter writer = factory.createXMLStreamWriter(new FileOutputStream("data/XmlStreaming.xml"),"UTF-8");
			Event event;
			
			//JsonArray jsonArray = jsonReader.readObject().getJsonArray("Employee");
			
			writer.writeStartDocument();
			while(jsonParser.hasNext())
			{
				event = jsonParser.next();
				
				switch(event)
				{
				case START_OBJECT : 
									event = jsonParser.next();
									if(event == Event.KEY_NAME)
									{
									element = jsonParser.getString();
									writer.writeStartElement(jsonParser.getString());
									}
								    break;
								    
				case KEY_NAME : writer.writeStartElement(jsonParser.getString());
								break;

				case VALUE_STRING : 
									writer.writeCharacters(jsonParser.getString());
									writer.writeEndElement();
									break;
				case START_ARRAY : array(jsonParser,writer);
									break;
								
				}
			}
			writer.writeEndDocument();	
			writer.flush();
			writer.close();
			}
	public void array(JsonParser jsonParser , XMLStreamWriter writer) throws XMLStreamException
	{
		Event event = jsonParser.next();
		int i = 0;
		while(event != Event.END_ARRAY)
		{
			if(event == Event.START_OBJECT)
			{
				if(i>0)
				{
					writer.writeStartElement(element);


				}
			}
			if(event == event.KEY_NAME)
			{
				writer.writeStartElement(jsonParser.getString());

			}
			if(event == Event.VALUE_STRING)
			{
				writer.writeCharacters(jsonParser.getString());
				writer.writeEndElement();

			}
			if(event == Event.END_OBJECT)
			{
				writer.writeEndElement();
				i++;
			}
			event = jsonParser.next();
		}
		
	}
	public static void main(String args[]) throws FileNotFoundException, IOException, XMLStreamException
	{
		JsonToXml j = new JsonToXmlImplB();
		j.jsonToXml();
	}
	

}
