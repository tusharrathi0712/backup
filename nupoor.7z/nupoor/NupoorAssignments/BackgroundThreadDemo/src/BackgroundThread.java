import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.concurrent.TimeUnit;

public class BackgroundThread {

	public BackgroundThread() {
		// TODO Auto-generated constructor stub
	}
	
	File file;
	FileWriter writer;
	BufferedWriter bufferedWriter;
	private long fileOpenTime;
	
	private void execute() throws IOException
	{	 
		file = new File("data/output.txt");
		writer = new FileWriter(file);
		bufferedWriter = new BufferedWriter(writer);
		fileOpenTime = System.currentTimeMillis();
		
		
		
		Runnable r = new Runnable() {
        public void run() {
        	long t = System.currentTimeMillis() - fileOpenTime;
        	if(t>TimeUnit.MINUTES.toMillis(2))
        	{
        		try {
					bufferedWriter.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        	}
        }
        
    };
    
    
	new Thread(r).start();



		while(true)
		{
			writer.write("hello");
			
		}
		
		
	}
	
	
	
	
	public static void main(String []args) throws IOException
	{
		BackgroundThread b = new BackgroundThread();
		b.execute();
	}

}
