import org.neo4j.graphdb.RelationshipType;
 
public enum CustomRelations implements RelationshipType {
	HAS_WRITTEN
}