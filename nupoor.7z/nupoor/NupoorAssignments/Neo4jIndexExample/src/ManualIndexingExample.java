import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Transaction;
import org.neo4j.graphdb.factory.GraphDatabaseFactory;
import org.neo4j.graphdb.index.Index;
import org.neo4j.graphdb.index.IndexManager;
 

 
public class ManualIndexingExample {
	private final static File DB_PATH = new File("D:/Neo4jDatabase");

	public static void main(final String[] args) throws IOException {
		GraphDatabaseService db = new GraphDatabaseFactory().newEmbeddedDatabase(DB_PATH);
		try (Transaction tx = db.beginTx()) {
			IndexManager indexManager = db.index();
 
			Node book1 = db.createNode(CustomLabels.BOOK);
			book1.setProperty("title", "Some book");
			Node book2 = db.createNode(CustomLabels.BOOK);
			book2.setProperty("title", "Another book");
 
			Index<Node> bookIndex = indexManager.forNodes("books");
			bookIndex.add(book1, "title", "Some book");
			bookIndex.add(book2, "title", "Another book");
 
			Node author1 = db.createNode(CustomLabels.AUTHOR);
			author1.setProperty("name", "Al Bundy");
			Node author2 = db.createNode(CustomLabels.AUTHOR);
			author2.setProperty("name", "Peggy Bundy");
 
			Index<Node> authorIndex = indexManager.forNodes("authors");
			authorIndex.add(author1, "name", "Al Bundy");
			authorIndex.add(author2, "name", "Peggy Bundy");
 
			author1.createRelationshipTo(book1, CustomRelations.HAS_WRITTEN);
			author2.createRelationshipTo(book2, CustomRelations.HAS_WRITTEN);
 
			
			tx.success();
		}
 
	}
}
