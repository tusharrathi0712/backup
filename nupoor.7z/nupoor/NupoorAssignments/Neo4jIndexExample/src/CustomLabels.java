import org.neo4j.graphdb.Label;
 
public enum CustomLabels implements Label {
	AUTHOR, BOOK
}