package com.load.cassandra.bulk;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import org.apache.cassandra.exceptions.InvalidRequestException;
import org.apache.cassandra.io.sstable.CQLSSTableWriter;
import com.opencsv.CSVReader;



public class ConvertCSVToSSTables {

	public static void main(String[] args) {
		String schema = "CREATE TABLE gfksample.responses (  Resp int PRIMARY KEY,  DID int,  QID int, Value int )";
		String insert = "INSERT INTO gfksample.responses (Resp, DID, QID, Value) VALUES (?, ?, ?,?)";
		String outFolderPath = "/root/sstablefiles/gfksample/responses";
		String csvFile = "/home/prashant/inputFileDir/responses.tab";
		
		CQLSSTableWriter writer = CQLSSTableWriter.builder().inDirectory(outFolderPath).forTable(schema)
				.using(insert).build();
		
        CSVReader reader = null;
        try {
            reader = new CSVReader(new FileReader(csvFile),'|');
            String[] line;
            while ((line = reader.readNext()) != null) {
            	writer.addRow(Integer.parseInt(line[0]), Integer.parseInt(line[1]), Integer.parseInt(line[2]),Integer.parseInt(line[3]));
            }
          
        } catch (InvalidRequestException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
        	try {
				writer.close();
				reader.close();
			} catch (IOException e) {
				System.out.println("IOException while closing the CQLSSTableWriter or CSVReader Object..");
			}
        }

	}
	

}
