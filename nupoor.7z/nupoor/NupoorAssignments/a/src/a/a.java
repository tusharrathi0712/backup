package a;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class a {

	
	File file = new File("C://Users/nupoork/Desktop/SampleJson.xml");
	
	
	public static void main(String a[]) throws IOException{
			
	
		String jsonString = new String(Files.readAllBytes(Paths.get("C://Users/nupoork/Desktop/SampleJson.txt")));
		System.out.println(jsonString);
	}

}
