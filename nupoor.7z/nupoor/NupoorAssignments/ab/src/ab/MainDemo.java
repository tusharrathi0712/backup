package ab;

public class MainDemo {

	public MainDemo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		InterfaceDemo i = new Demo();
		i.show();
		AbstractDemo a = new Demo();
		a.show();
	}

}
