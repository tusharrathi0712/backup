package ab;
 public  class AbstractDemo {

	public AbstractDemo() {
		// TODO Auto-generated constructor stub
	}

	public  void show(){
		System.out.println("in ab");
	}
}
