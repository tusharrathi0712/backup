package ab;


public class Man {
	
	public static void main(String args[]){
		String a  = new String("before");
		String b = a.concat("after");
		
		System.out.println(a);
		System.out.println(b);
	}
}
