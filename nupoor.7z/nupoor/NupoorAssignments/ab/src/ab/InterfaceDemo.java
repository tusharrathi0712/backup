package ab;

public interface InterfaceDemo {

	public void show();
}
