package ab;

public class Test {
	public static String foo() {
		System.out.println("Test foo called");
		return "";
	}

	public static void main(String args[]) {
		Test obj = null;
		System.out.println(obj.foo());
		String s1 = "Test";
        String s2 = "Test";
        System.out.println(s1 == s2);
        System.out.println(s1.hashCode());
        System.out.println(s2.hashCode());
        String s3 = new String("Test");
        String s6 = new String("Test");
        System.out.println(s3.hashCode());
        System.out.println(s6.hashCode());
        System.out.println(s1 == s3);
        System.out.println(s3 == s6);
        String s4 = s3.intern();
        String s5 = s6.intern();
        System.out.println("------------------------");
        System.out.println("s1 == s4" + (s1 == s4));
        System.out.println( s2 == s5);
        System.out.println( s4 == s5);
        System.out.println( s3 == s5);
        System.out.println( s6 == s5);
	}
}