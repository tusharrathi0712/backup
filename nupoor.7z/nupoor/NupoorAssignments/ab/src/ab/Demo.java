package ab;

public class Demo extends AbstractDemo implements InterfaceDemo{

	public Demo() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("in demo");
	}

	

	
	

}
