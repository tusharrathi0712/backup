package ab;

public class PermutationString {

	public PermutationString() {
	
	}

	public static Set<String> permutationFinder(String s){
		
	}
	public static void main(String args[]){
		String s = "AAC";
		permutationFinder(s);
	}
}
