package com.org.properties;

public interface Properties {

	String METADATA_BROKER_LIST = "metadata.broker.list";
	String SERIALIZER_CLASS  = "serializer.class";
	String TOPIC_NAME = "topic.name";
	String NUM_RECORDS = "num.records";
	String ZOOKEEPER_CONNECT = "zookeeper.connect";
	String GROUP_ID = "group.id";
	String NUM_PARTITIONS= "num.partitions";
}
