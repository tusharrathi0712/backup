package com.org.properties;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesCache {
	
	
	String fileName;
	Properties property ;
	
	
	
	public PropertiesCache(String fileName)
	{
		this.fileName = fileName;
		property = new Properties();
	      InputStream in = this.getClass().getClassLoader().getResourceAsStream(this.fileName);
	      try {
	    	  property.load(in);
	      } catch (IOException e) {
	          e.printStackTrace();
	      }

	}
	
	public String getProperty(String key)
	{
		return 	property.getProperty(key);
		
	}
	
	public Properties getProperties()
	{
		return property;
	}
	
	
}
