package com.org.kafka;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import com.org.properties.Properties;
import com.org.properties.PropertiesCache;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;

public class KafkaProducer implements Properties {
	static String TOPIC;
	private PropertiesCache propertiesCache;
	private ProducerConfig producerConfig;

	public KafkaProducer() {
		propertiesCache = new PropertiesCache("producer.properties");
		producerConfig = new ProducerConfig(propertiesCache.getProperties());

		TOPIC = propertiesCache.getProperty(TOPIC_NAME);
		// ZkClient zkClient = new ZkClient("localhost:2181", 100000, 100000,
		// ZKStringSerializer$.MODULE$);
		java.util.Properties p = new java.util.Properties();
		// if(!AdminUtils.topicExists(zkClient, TOPIC))
		// AdminUtils.createTopic(zkClient, TOPIC,6,
		// 1,propertiesCache.getProperties());
		/*
		 * int sessionTimeoutMs = 10000; int connectionTimeoutMs = 10000;
		 * ZkClient zkClient = new ZkClient("localhost:2181", sessionTimeoutMs,
		 * connectionTimeoutMs);l
		 * 
		 * TopicMetadata metaData =
		 * AdminUtils.fetchTopicMetadataFromZk(TOPIC,zkClient);
		 * System.out.println(metaData.partitionsMetadata().size());
		 */

	}

	private void sendMessages() throws IOException {
		Producer<String, String> producer = new Producer<String, String>(producerConfig);

		int i = 0;
		//FileInputStream fis = new FileInputStream(new File("data/input.txt"));

		// Construct BufferedReader from InputStreamReader
		//BufferedReader br = new BufferedReader(new InputStreamReader(fis));
		//String line = br.readLine();
		//String fields[] = line.split(" ");
		int noOfRecords = Integer.parseInt(propertiesCache.getProperty(NUM_RECORDS));
		String randomMessge = "Hi";
		System.out.println(randomMessge);
		while (i < noOfRecords) {
			/*
			 * String randomMessge = generateMessages(fields); String
			 * randomMessageFields[] = randomMessge.split(" "); String key =
			 * randomMessageFields[0]; //long epoch =
			 * Long.parseLong(randomMessageFields[1]); //String format =
			 * "dd-MM-yyyy HH.mm.ss"; // String currenttime = new
			 * java.text.SimpleDateFormat(format).format(new java.util.Date
			 * (epoch*1000)); // System.out.println("ID --> "+key+"  --  "
			 * +currenttime);
			 */
			randomMessge = randomMessge + i;

			KeyedMessage<String, String> message = new KeyedMessage<String, String>(TOPIC, randomMessge);
			producer.send(message);
			i++;
		}
	//	br.close();
		producer.close();

	}

	/*
	 * private String generateMessages(String[] fields) { FileGenerator
	 * fileGenerator = new FileGenerator();
	 * FileGenerator.setId(Integer.parseInt(fields[0]));
	 * fileGenerator.setEpoch(System.currentTimeMillis());
	 * fileGenerator.setAssetId(fields[1]); fileGenerator.setName(fields[2]);
	 * //System.out.println(fields[3]); fileGenerator.setCompanyName(fields[3]);
	 * fileGenerator.setLocation(fields[4]); fileGenerator.setCity(fields[5]);
	 * fileGenerator.setState(fields[6]); fileGenerator.setCountry(fields[7]);
	 * fileGenerator.setGender(fields[8]); fileGenerator.setSsn(fields[9]);
	 * fileGenerator.setIpAddress(fields[10]); return fileGenerator.toString();
	 * 
	 * }
	 */

	public static void main(String[] argv) throws IOException {

		
		KafkaProducer kafkaProducer = new KafkaProducer();
		kafkaProducer.sendMessages();
	}
}
