import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonStructure;
import javax.json.JsonValue;
import javax.json.JsonWriter;



public class JsonFilterStream {

	

	public void filterJson(InputStream in,OutputStream out) throws IOException, InstantiationException, IllegalAccessException
	{
		 JsonReader reader = Json.createReader(in);
		JsonWriter writer = Json.createWriter(out);
		JsonObject jsonOject = reader.readObject();
		JsonArray jsonArray = null;
		JsonArrayBuilder builder = Json.createArrayBuilder();

		 JsonArray array;

		for(Entry<String,JsonValue> e : jsonOject.entrySet())
		{
			JsonObject jsonObject1 = (JsonObject) jsonOject.get(e.getKey());

			//boolean flag = true;
			for(int j=0;j<jsonObject1.size();j++)
			 {
				//flag=0;
				 for(Entry<String,JsonValue> e1 : jsonObject1.entrySet())
				 {
					    System.out.println(e1.getKey());
						 jsonArray = jsonObject1.getJsonArray(e1.getKey());
						Iterator<JsonValue> it = jsonArray.iterator();
						ArrayList<JsonObject> list = new ArrayList();     
						System.out.println(jsonArray.size());
						for(int i=0; i<jsonArray.size();i++)
						{
							boolean flag = true;
							JsonObject jo = jsonArray.getJsonObject(i);

							for(Entry<String,JsonValue> entry : jo.entrySet())
							{
								
								if(entry.getKey().equals("emplid"))
								{
									
									if(entry.getValue().toString().equalsIgnoreCase("2222"))	
									{
										flag = false;
										
									break;
									}

									
								}
									
							}
							if(flag)
							{
								
								builder.add(jo);


								
							}
						
						}
				 }
			 }


		}
		array = builder.build();
		JsonObjectBuilder arrayBuilder = Json.createObjectBuilder();
		arrayBuilder.add("Employee", array);
		JsonObjectBuilder rootBuilder = Json.createObjectBuilder();
		rootBuilder.add("Employees", arrayBuilder);
		JsonObject root = rootBuilder.build();
		writer.writeObject(root);
		writer.close();

		
		
		
		
	}

	public static void main(String[] args) throws IOException, InstantiationException, IllegalAccessException {
		
		
		InputStream in = new FileInputStream("data/inputJson.json");
		OutputStream out = new FileOutputStream("data/outputJson.json");
		JsonFilterStream jfs = new JsonFilterStream();
		jfs.filterJson(in,out);
		


	}

}
