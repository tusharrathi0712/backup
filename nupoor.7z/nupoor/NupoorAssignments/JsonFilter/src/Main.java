import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws IOException, InstantiationException, IllegalAccessException {
		InputStream in = new FileInputStream("data/inputJson.json");
		OutputStream out = new FileOutputStream("data/outputJson.json");
		JsonFilter filter = new JsonFilter();
		filter.filterJson(in,out);

	}

}
