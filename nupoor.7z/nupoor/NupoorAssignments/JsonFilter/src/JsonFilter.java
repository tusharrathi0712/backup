import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

import com.jayway.jsonpath.Criteria;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.Filter;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.WriteContext;
import com.jayway.jsonpath.internal.JsonReader;

import net.minidev.json.reader.JsonWriter;





public class JsonFilter {

	public JsonFilter() {
		
		
	}
	
	
	public void filterJson(InputStream in,OutputStream out) throws IOException, InstantiationException, IllegalAccessException
	{
		//JsonPath jsonPath = JsonPath.compile("$.Employees.Employee.book[1]");
	    Filter[] feq = new Filter[1];
	    feq[0]=	Filter.filter(Criteria.where("emplid").eq("2222"));

		JsonPath jsonPath = JsonPath.compile("$.Employees.Employee[?]", feq);
	     System.out.println((jsonPath.read(in)).toString());
	     
	//	System.out.println(jsonPath.read("data/inputJson.json"));
		/*JsonReader jsonReader = JsonReader.class.newInstance();
		DocumentContext jsonReader1 = jsonReader.parse(in);
		WriteContext w = jsonReader1.delete(jsonPath);
		out.write(w.jsonString().getBytes());
*/		
	}

}
