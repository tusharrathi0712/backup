import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonValue;
import javax.json.JsonWriter;
import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;



public class JsonFilterA {

	

	@SuppressWarnings({ "incomplete-switch", "unchecked" })
	public void filterJson(InputStream in,OutputStream out) throws IOException, InstantiationException, IllegalAccessException
	{
		JsonParser jsonParser = Json.createParser(in);
		FileWriter writer = new FileWriter("data/outputJson1.json");

		Event event;
		JSONObject root = null;
		JSONObject employee = null;
		while(jsonParser.hasNext())
		{
			event = jsonParser.next();
			String name = null;
			switch(event)
			{
			case START_OBJECT :  root = new JSONObject();
								break;
			case KEY_NAME :  jsonParser.getString();
							 break;
			case START_ARRAY : employee = array(jsonParser);
								break;
								
			}
		}
		
		
		root.put("Employees", employee);
		writer.write(root.toJSONString());
		writer.close();
		
	}

	@SuppressWarnings("unchecked")
	public JSONObject array(JsonParser jsonParser)
	{
		Event event = jsonParser.next();
		JSONArray jsonArray = new JSONArray();
		String key[] = new String[100];
		String values[] = new String[100];
		JSONObject jsonObject = null;
		boolean flag = true;
		int i=0;
		while(event != event.END_ARRAY)
		{
		switch(event)
		{
		case START_OBJECT : jsonObject = new JSONObject();
							flag = true;
							i=0;
							break;
		case KEY_NAME : 	key[i] = new String();
							key[i]	= jsonParser.getString();
							break;
							
		case VALUE_STRING : if(jsonParser.getString().equals("admin"))
								flag = false;
							if(flag)
							{
							values[i] = new String();
							values[i]	= jsonParser.getString();
							i++;
							}
							break;
							
		case END_OBJECT :	if(flag)
							{
							for(int j=0;j<i;j++)
							jsonObject.put(key[j], values[j]);
							jsonArray.add(jsonObject);
							}
							break;
		default:
			break;

		}
		event = jsonParser.next();
		}
		JSONObject employee = new JSONObject();
		employee.put("Employee", jsonArray);
		return employee;
	}
	public static void main(String[] args) throws IOException, InstantiationException, IllegalAccessException {
		
		
		InputStream in = new FileInputStream("data/inputJson.json");
		OutputStream out = new FileOutputStream("data/outputJson1.json");
		JsonFilterA jfs = new JsonFilterA();
		jfs.filterJson(in,out);
		


	}

}
