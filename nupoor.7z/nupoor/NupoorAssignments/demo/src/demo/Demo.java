package demo;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.json.JSONException;
public class Demo {
	
	
	public static void main(String args[]) throws JSONException, IOException, ParseException
	{
		String ipName = null;
		String sarfilename = "Scale2_Test24_2Studys_TestRun24_50_10.0.1.6_2016_12_07_08_40_30_RAM.log";
		String names[] = sarfilename.split("_");
		for(int i=0;i<names.length;i++)
		{
			if(names[i].contains("."))
			{
				if( ! names[i].contains("log"))
				{
					ipName=names[i];
				}
			}
		}
		System.out.println(ipName);
		ipName = ipName.replace('.', '_');
		System.out.println(ipName);


		ZonedDateTime utc = ZonedDateTime.now(ZoneOffset.UTC);
		TimeZone timeZone = TimeZone.getTimeZone("UTC");
		 System.out.println("DATETIME = " +utc.format(DateTimeFormatter.ofPattern("yyyy:MM:dd")));
		 
		 DateFormat formatter = new SimpleDateFormat("yyyy:MM:dd hh:mm:ss a");
		 
			Date begin = (Date) formatter.parse("2016:12:07 02:43:22 PM");
			Calendar calendar = Calendar.getInstance(timeZone);
			   calendar.setTime(begin);
			   calendar.add(Calendar.HOUR, 12);
			   begin = calendar.getTime();
			   System.out.println("kkdkfj "+begin);
			//System.out.println(begin.getHours());
			//System.out.println("time--------------  "+begin.toString());
			/*begin.setYear(new Date().getYear());
			begin.setMonth(new Date().getMonth());
			begin.setDate(new Date().getDate());
			*/// System.out.println(" Final Date " + begin);
			long milliseconds = begin.getTime();
			System.out.println(milliseconds);
			//formatter = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss");
			calendar = Calendar.getInstance();
			calendar.setTimeInMillis(milliseconds);
			System.out.println("dfs "+formatter.format(calendar.getTime())); 
			// System.out.println("Milliseconds:" + milliseconds);
			// System.out.println(milliseconds * 1000000);
			//return milliseconds * 1000000;
	        
//		String jsonString = new String(Files.readAllBytes(Paths.get("C://Users/nupoork/Desktop/SampleJson.txt")));
//		JSONObject json = new JSONObject(jsonString);
//		String xml = XML.toString(json);
//		System.out.println(xml);
//		
	}

}
