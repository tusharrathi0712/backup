import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.interfaces.DSAParams;
import java.security.interfaces.DSAPrivateKey;
import java.security.interfaces.DSAPublicKey;
import java.security.spec.DSAPrivateKeySpec;
import java.security.spec.DSAPublicKeySpec;
import java.security.spec.KeySpec;
import java.util.Formatter;

public class DSASign {
  public static void main(String[] argv) throws Exception {
    KeyPairGenerator keyGen = KeyPairGenerator.getInstance("DSA");
    
    keyGen.initialize(1024);
    KeyPair keypair = keyGen.genKeyPair();
    DSAPrivateKey privateKey = (DSAPrivateKey) keypair.getPrivate();
    DSAPublicKey publicKey = (DSAPublicKey) keypair.getPublic();

    DSAParams dsaParams = privateKey.getParams();
    BigInteger p = dsaParams.getP();
    BigInteger q = dsaParams.getQ();
    BigInteger g = dsaParams.getG();
    BigInteger x = privateKey.getX();
    BigInteger y = publicKey.getY();

    
    KeyFactory keyFactory = KeyFactory.getInstance("DSA");
    KeySpec privateKeySpec = new DSAPrivateKeySpec(x, p, q, g);
    PrivateKey privateKey1 = keyFactory.generatePrivate(privateKeySpec);

    String m = "Digital Signature Algorithm";
    byte[] buffer = new byte[1024];
    buffer = m.getBytes();
    

    Signature sig = Signature.getInstance(privateKey1.getAlgorithm());
    sig.initSign(privateKey1);
    sig.update(buffer, 0, buffer.length);
    
    byte [] signature = sig.sign();
    Formatter formatter = new Formatter();
    for(byte b : signature)
    {
    	formatter.format("%02x", b);
    }
    
    //System.out.println(formatter.toString());
    
    KeySpec publicKeySpec = new DSAPublicKeySpec(y,p,q,g);
    PublicKey publicKey1 = keyFactory.generatePublic(publicKeySpec);
    Signature sig1 = Signature.getInstance("DSA");
    sig1.initVerify(publicKey1);
    sig1.update(buffer,0,buffer.length);
    boolean verified = sig1.verify(signature);
    if(verified)
    {
    	System.out.println("Signature verified successfully");
    }
    
  }
  
}
