/*package com.dsa.main;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;

public class SignatureTest
{
   public static void main(String[] args)
   {
	   KeyPairGenerator pairgen;
	   KeyPair keyPair = null;
	   
      try
      {
         if (args[0].equals("-genkeypair"))
         {
            pairgen = KeyPairGenerator.getInstance("DSA");
            SecureRandom random = new SecureRandom();
            pairgen.initialize(KEYSIZE, random);
            keyPair = pairgen.generateKeyPair();
            PublicKey publicKey = keyPair.getPublic();
            
         }
         else if (args[0].equals("-sign"))
         {
            
            PrivateKey privkey = (PrivateKey) keyPair.getPrivate();
            

            Signature signalg = Signature.getInstance("DSA");
            signalg.initSign(privkey);

            //File infile = new File(args[1]);
            //InputStream in = new FileInputStream(infile);
            //int length = (int) infile.length();
            byte[] message = new byte[length];
            //in.read(message, 0, length);
            //in.close();

            signalg.update(message);
            byte[] signature = signalg.sign();

            DataOutputStream out = new DataOutputStream(new FileOutputStream(args[2]));
            int signlength = signature.length;
            out.writeInt(signlength);
            out.write(signature, 0, signlength);
            out.write(message, 0, length);
            out.close();
         }
         else if (args[0].equals("-verify"))
         {
            ObjectInputStream keyIn = new ObjectInputStream(new FileInputStream(args[2]));
            PublicKey pubkey = (PublicKey) keyIn.readObject();
            keyIn.close();

            Signature verifyalg = Signature.getInstance("DSA");
            verifyalg.initVerify(pubkey);

            File infile = new File(args[1]);
            DataInputStream in = new DataInputStream(new FileInputStream(infile));
            int signlength = in.readInt();
            byte[] signature = new byte[signlength];
            in.read(signature, 0, signlength);

            int length = (int) infile.length() - signlength - 4;
            byte[] message = new byte[length];
            in.read(message, 0, length);
            in.close();

            verifyalg.update(message);
            if (!verifyalg.verify(signature)) System.out.print("not ");
            System.out.println("verified");
         }
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
   }

   private static final int KEYSIZE = 512;
}

   
  
*/