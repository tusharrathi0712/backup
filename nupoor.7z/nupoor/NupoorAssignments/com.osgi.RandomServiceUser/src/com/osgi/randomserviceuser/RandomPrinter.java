package com.osgi.randomserviceuser;

import com.osgi.randomservice.IRandomGenerator;

public class RandomPrinter extends Thread{
	
	
	private final IRandomGenerator randomGenerator;
	private boolean run  = true;
	
	
	public RandomPrinter(final IRandomGenerator randomGenerator)
	{
		this.randomGenerator = randomGenerator;
	}
	
	
	
	public void run()
	{
		if(this.run)
		{
			for(int i=0;i<5;i++)
			{
			System.out.println("In user "+"\n new random no : "+randomGenerator.generate(300));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		}
		System.out.println("the process was terminated");
	}
	
	
	
	public void close()
	{
		this.run = false;
	}

}
