package com.osgi.randomserviceuser;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.util.tracker.ServiceTracker;

import com.osgi.randomservice.IRandomGenerator;

public class UserActivator implements BundleActivator {

	private RandomPrinter randomPrinter,randomPrinter1;
	//ServiceReference serviceReference;
	ServiceTracker serviceTracker;
	public void start(BundleContext context) throws Exception {
		System.out.println("USER: Lets start: ");
		//serviceReference = context.getServiceReference(IRandomGenerator.class.getName());
		serviceTracker = new RandomNumberTracker(context);
		serviceTracker.open();
		IRandomGenerator randomGenerator = (IRandomGenerator) serviceTracker.getService();
		this.randomPrinter = new RandomPrinter(randomGenerator);
		this.randomPrinter1 = new RandomPrinter(randomGenerator);
		this.randomPrinter.start();
		this.randomPrinter1.start();
		}
	
	public void stop(BundleContext context) throws Exception {
		System.out.println("finish");
		this.randomPrinter.close();
		serviceTracker.close();
		
	}

}
