package com.osgi.randomserviceuser;

import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.util.tracker.ServiceTracker;

import com.osgi.randomservice.IRandomGenerator;
import com.osgi.randomservice.RandomGenerator;

public class RandomNumberTracker extends ServiceTracker {

	public RandomNumberTracker(BundleContext context) {
		super(context,IRandomGenerator.class.getName(),null);
		
	}
	
	
	public Object addingService(ServiceReference reference)
	{
		System.out.println("in the service tracker : "+reference.getBundle());
		return super.addingService(reference);
	}

	
	public void removedService(ServiceReference reference , Object service)
	{
		System.out.println("removed service tracker : "+reference.getBundle());
		super.removedService(reference, service);
	}
}
