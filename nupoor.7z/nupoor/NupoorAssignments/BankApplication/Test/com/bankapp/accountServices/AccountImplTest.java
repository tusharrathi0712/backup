package com.bankapp.accountServices;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.bankapp.Exceptions.NoSuchAccount;
import com.bankapp.Exceptions.NotEnoughBalance;
import com.bankapp.data.CustomerData;
import com.bankapp.pojo.AccountHolder;

public class AccountImplTest {

	private AccountImpl accountImpl;
	private AccountHolder accountHolder;
	private String name;
	private long phoneNo;
	private String email;
	private long accontId;
	private double balance;

	@Before
	public void setUp() {
		accountImpl = new AccountImpl();
		accountHolder = new AccountHolder();
		name = "abc";
		phoneNo = 9876543290l;
		email = "nup@cybage.com";
		balance = 15000;
		accontId = 100;
		accountHolder.setAccountId(accontId);
		accountHolder.setBalance(balance);
		accountHolder.setName(name);
		accountHolder.setPhoneNumber(phoneNo);
		accountHolder.setEmailId(email);
		CustomerData.accounts.put((long) accontId, accountHolder);
	}

	@Test
	public void openAccountTest() throws NotEnoughBalance {
		long accId = accountImpl.open(name, phoneNo, email, balance);
		assertTrue(CustomerData.accounts.containsKey(accId));
		assertEquals(CustomerData.accounts.get(accId).getName(), name);
		assertEquals(CustomerData.accounts.get(accId).getEmailId(), email);
	}

	@Test
	public void openAccountTestForException() {
		balance = 150;
		try {
			accountImpl.open(name, phoneNo, email, balance);
		} catch (NotEnoughBalance e) {
			assertThat(e.getMessage(), is("Amount must be at least 5000"));
		}
	}

	@Test
	public void depositTest() {
		double balance = accountImpl.deposite(2000, accontId);
		assertEquals(balance, 17000, 0.001);

	}

	@Test
	public void viewProfileTest() throws NoSuchAccount {
		AccountHolder a = accountImpl.viewProfile(accontId);
		assertEquals(a.getName(), name);
		assertEquals(a.getPhoneNumber(), phoneNo);
		assertEquals(a.getEmailId(), email);
		assertEquals(a.getBalance(), balance, 0.001);
	}

	@Test
	public void withdrawTest() throws NotEnoughBalance {
		double balance = accountImpl.withdraw(2000, accontId);
		assertEquals(balance, 13000, 0.001);
	}

	@Test
	public void balanceEnquiryTest() {
		double availableBalance = accountImpl.balanceEnquiry(accontId);
		assertEquals(availableBalance, balance, 0.001);
	}

	@Test
	public void transferTest() throws NoSuchAccount, NotEnoughBalance {
		accountHolder = new AccountHolder();
		long toAccId = 101;
		accountHolder.setAccountId(101);
		accountHolder.setBalance(12000);

		CustomerData.accounts.put((long) toAccId, accountHolder);
		double availableBalance = accountImpl.transfer(accontId, toAccId, 2000);
		assertEquals(availableBalance, 13000, 0.001);
		assertEquals(CustomerData.accounts.get(toAccId).getBalance(), 14000, 0.001);
	}

	@Test
	public void closeAccountTest() throws NoSuchAccount {
		accountImpl.close(accontId);
		assertFalse(CustomerData.accounts.containsKey(accontId));
	}

	@Test(expected = NotEnoughBalance.class)
	public void transferTestForException() throws NoSuchAccount, NotEnoughBalance {

		accountHolder = new AccountHolder();
		long toAccId = 101;
		accountHolder.setAccountId(101);
		CustomerData.accounts.put((long) toAccId, accountHolder);
		accountImpl.transfer(accontId, toAccId, 2000000);
	}

	@Test(expected = NoSuchAccount.class)
	public void transferTestForExceptionForAccount() throws NoSuchAccount, NotEnoughBalance {
		accountImpl.transfer(accontId, 11111, 20);
	}

	@Rule
	public ExpectedException exception = ExpectedException.none();

	@Test
	public void withdrawTestForException() throws NotEnoughBalance {
		exception.expect(NotEnoughBalance.class);
		exception.expectMessage("Insufficient Balance");
		accountImpl.withdraw(200000, accontId);
	}

	@Test
	public void closeTestForException() throws NoSuchAccount {
		long accId = 1;
		exception.expect(NoSuchAccount.class);
		exception.expectMessage("No such account exists");
		accountImpl.close(accId);
	}

	@Test
	public void viewProfileTestForException() throws NoSuchAccount {
		long accId = 1;
		exception.expect(NoSuchAccount.class);
		exception.expectMessage("No such account exists");
		accountImpl.viewProfile(accId);
	}

}