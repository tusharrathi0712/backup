package com.bankapp.accountServices;

import com.bankapp.Exceptions.NoSuchAccount;
import com.bankapp.Exceptions.NotEnoughBalance;
import com.bankapp.data.CustomerData;
import com.bankapp.pojo.AccountHolder;

public class AccountImpl implements Account {

	private static long accountId = 1000;

	@Override
	public long open(String name, long phNo, String email, double balance) throws NotEnoughBalance {
		if (balance < 5000) {
			throw new NotEnoughBalance("Amount must be at least 5000");
		}
		AccountHolder accountHolder = new AccountHolder();
		accountHolder.setAccountId(++accountId);
		accountHolder.setName(name);
		accountHolder.setPhoneNumber(phNo);
		accountHolder.setEmailId(email);
		accountHolder.setBalance(balance);
		CustomerData.accounts.put(accountId, accountHolder);
		return accountId;
	}

	@Override
	public void close(long accountId) throws NoSuchAccount {
		if (!CustomerData.accounts.containsKey(accountId)) {
			throw new NoSuchAccount("No such account exists");
		}
		CustomerData.accounts.remove(accountId);
	}

	@Override
	public double withdraw(double amount, long accountId) throws NotEnoughBalance {

		AccountHolder accountHolder = CustomerData.accounts.get(accountId);
		double balance = accountHolder.getBalance();
		if (amount > balance) {
			throw new NotEnoughBalance("Insufficient Balance");
		}
		accountHolder.setBalance(balance - amount);
		return accountHolder.getBalance();
	}

	@Override
	public double deposite(double amount, long accountId) {
		AccountHolder accountHolder = CustomerData.accounts.get(accountId);
		accountHolder.setBalance(accountHolder.getBalance() + amount);
		return accountHolder.getBalance();
	}

	@Override
	public double balanceEnquiry(long accountId) {
		return CustomerData.accounts.get(accountId).getBalance();
	}

	@Override
	public double transfer(long fromAccId, long toAccId, double amount) throws NoSuchAccount, NotEnoughBalance {
		if (!CustomerData.accounts.containsKey(toAccId)) {
			throw new NoSuchAccount("No such account exists");
		}
		AccountHolder fromAcc = CustomerData.accounts.get(fromAccId);
		double fromAccntBalance = fromAcc.getBalance();
		if (fromAccntBalance < amount) {
			throw new NotEnoughBalance("Insufficient Balance");
		}
		if (fromAccId == toAccId) {
			return -1;
		}
		fromAcc.setBalance(fromAccntBalance - amount);
		AccountHolder toAcc = CustomerData.accounts.get(toAccId);
		toAcc.setBalance(toAcc.getBalance() + amount);
		return fromAcc.getBalance();
	}

	public AccountHolder viewProfile(long accountId) throws NoSuchAccount {
		if (!CustomerData.accounts.containsKey(accountId)) {
			throw new NoSuchAccount("No such account exists");
		}
		return CustomerData.accounts.get(accountId);
	}

}
