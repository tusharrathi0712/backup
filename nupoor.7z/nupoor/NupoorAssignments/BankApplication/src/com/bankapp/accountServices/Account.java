package com.bankapp.accountServices;

import com.bankapp.Exceptions.NoSuchAccount;
import com.bankapp.Exceptions.NotEnoughBalance;

public interface Account {

	public abstract long open(String name, long phNo, String email, double balance) throws NotEnoughBalance;

	public abstract void close(long accountId) throws NoSuchAccount;

	public abstract double withdraw(double amount, long accountId) throws NotEnoughBalance;

	public abstract double deposite(double amount, long accountId);

	public abstract double balanceEnquiry(long accId);

	public abstract double transfer(long fromAccId, long accountId, double amount) throws NoSuchAccount, NotEnoughBalance;
}
