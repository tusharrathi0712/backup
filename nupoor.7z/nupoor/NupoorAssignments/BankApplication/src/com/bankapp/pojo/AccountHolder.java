package com.bankapp.pojo;

public class AccountHolder {

	private long accountId;
	private String name;
	private long phoneNumber;
	private String emailId;
	private double balance;

	public long getAccountId() {
		return accountId;
	}

	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}

	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "\n Welcome " + name + "\n\n" + "\n Account Number : " + accountId + "\n Contact Number : " + phoneNumber
				+ "\n Email address :  " + emailId + "\n Account Balance : " + balance + "\n";
	}

}
