package com.bankapp.data;

import java.util.HashMap;
import java.util.Map;

import com.bankapp.pojo.AccountHolder;

public class CustomerData {

	public static Map<Long, AccountHolder> accounts = new HashMap<Long, AccountHolder>();

}