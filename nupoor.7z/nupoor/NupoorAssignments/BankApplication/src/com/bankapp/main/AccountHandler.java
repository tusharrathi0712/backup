package com.bankapp.main;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.bankapp.Exceptions.NoSuchAccount;
import com.bankapp.Exceptions.NotEnoughBalance;
import com.bankapp.accountServices.Account;
import com.bankapp.accountServices.AccountImpl;
import com.bankapp.pojo.AccountHolder;

public class AccountHandler {

	private static Scanner scanner = new Scanner(System.in);

	public static void main(String args[]) {
		getInput();
		scanner.close();
	}

	public static void getInput() {
		System.out.println("\n\t\t Welcome to ABC Bank\n\n");
		System.out.println(" 1. Create an Account");
		System.out.println(" 2. View Profile");
		System.out.println(" 3. Close an Account");
		System.out.println(" 4. Exit");
		try {
			int choice = scanner.nextInt();
			AccountImpl accountImpl = new AccountImpl();
			switch (choice) {
			case 1:
				System.out.println(" Enter your name");
				String name = scanner.next();
				if(name.matches("([a-zA-Z]*[0-9]+[a-zA-Z]*)*"))
				{
					System.out.println("Invalid Name");
					getInput();
					return;
				}
				System.out.println(" Enter your contact number");
				long phoneNo = scanner.nextLong();
				System.out.println(" Enter your email address");
				String email = scanner.next();
				String Email_Regex = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z]+(\\.[A-Za-z]+)+$";
				email.matches(Email_Regex);
				if (!(email.matches(Email_Regex))) {
					System.out.println(" Invalid EmailId  (eg.abc@xyz.com)");
					getInput();
					return;
				}
				System.out.println(" Enter amount");
				double balance = scanner.nextDouble();
				long accountId = 0;
				try {
					accountId = accountImpl.open(name, phoneNo, email, balance);
					System.out.println("\n Your account has been created");
					System.out.println("\n Your account number is: " + accountId);
				} catch (NotEnoughBalance e) {
					System.out.println(e.getMessage());
				}
				break;

			case 2:
				getViewProfileData();
				break;

			case 3:
				System.out.println("Enter account number to close");
				accountId = scanner.nextLong();
				System.out.println("Are you sure you want to close an account");
				System.out.println("Type Y / N");
				String s = scanner.next();
				if (s.equalsIgnoreCase("Y")) {
					try {
						accountImpl.close(accountId);
						System.out.println(" Your account has been closed ");
					} catch (NoSuchAccount e) {
						System.out.println(e.getMessage());
					}
				}
				break;

			case 4:
				System.out.println("\n\t\t Thank you for using ABC Bank");
				break;

			default:
				System.out.println(" Invalid option ");
				System.out.println(" Please try again ");
				getInput();
			}
			if (choice == 1 || choice == 3) {
				getInput();
			}

		} catch (InputMismatchException e) {
			System.out.println(" Invalid value ");
			System.out.println(" Please try again ");
			scanner.next();
			getInput();
		}
	}

	public static void getViewProfileData() {
		AccountImpl accountImpl = new AccountImpl();
		System.out.println("\n\t Enter your account number");
		long accountId = scanner.nextLong();
		try {
			AccountHolder accountHolder = accountImpl.viewProfile(accountId);
			System.out.println(accountHolder);
			executeViewProfile(accountId, accountImpl);

		} catch (NoSuchAccount e) {
			System.out.println(e.getMessage());
			getInput();
		}
	}

	public static void executeViewProfile(long accountId, Account accountImpl) {

		double balance;
		int ch;
		System.out.println("\n1. Deposit");
		System.out.println("2. Withdraw");
		System.out.println("3. Balance Enquiry");
		System.out.println("4. Transfer");
		System.out.println("5. Close an account");
		System.out.println("6. Home");
		try {
			ch = scanner.nextInt();
			switch (ch) {
			case 1:
				System.out.println("\n\t Enter amount to deposit");
				double amount = scanner.nextDouble();
				balance = accountImpl.deposite(amount, accountId);
				System.out.println("\n\t Now the available balance is : " + balance);
				break;

			case 2:
				System.out.println("\n\t Enter amount to withdraw");
				amount = scanner.nextDouble();
				try {
					balance = accountImpl.withdraw(amount, accountId);
					System.out.println("\n\t Now the available balance is : " + balance);
				} catch (NotEnoughBalance e1) {
					System.out.println(e1.getMessage());
				}
				break;

			case 3:
				balance = accountImpl.balanceEnquiry(accountId);
				System.out.println("\n\t Your account balance is : " + balance);
				break;

			case 4:
				System.out.println("\n\t Enter account number of beneficiary to trasfer money");
				long toAccountId = scanner.nextLong();
				System.out.println("\n\t Enter amount to be transfered");
				amount = scanner.nextDouble();
				try {
					balance = accountImpl.transfer(accountId, toAccountId, amount);
					if (balance < 0)

						System.out.println("You cannot transfer to this account");
					else
						System.out.println("\n\t Now the available balance is: " + balance);
				} catch (NoSuchAccount | NotEnoughBalance e) {
					System.out.println(e.getMessage());

				}
				break;

			case 5:
				System.out.println(" Are you sure you want to close this account");
				System.out.println(" Type Y / N");
				String s = scanner.next();
				if (s.equalsIgnoreCase("Y")) {
					try {
						accountImpl.close(accountId);
						System.out.println(" Your account has been closed ");
						getInput();
					} catch (NoSuchAccount e) {
						System.out.println(e.getMessage());
					}
					return;
				}
				break;

			case 6:
				break;

			default:
				System.out.println(" Invalid option ");
				System.out.println(" Please try again ");
				executeViewProfile(accountId, accountImpl);
			}
			if (ch > 0 && ch < 6) {
				executeViewProfile(accountId, accountImpl);
			} else {
				if (ch == 6)
					getInput();
			}
		} catch (InputMismatchException e) {
			System.out.println(" Invalid value ");
			System.out.println(" Please try again ");
			scanner.next();
			executeViewProfile(accountId, accountImpl);
		}
	}

}
