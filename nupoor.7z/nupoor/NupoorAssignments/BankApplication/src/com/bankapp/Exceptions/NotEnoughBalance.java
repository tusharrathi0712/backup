package com.bankapp.Exceptions;

public class NotEnoughBalance extends Throwable {

	private String message;

	public NotEnoughBalance(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	

}
