import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class HmacSha1Signature {
private static final String HMAC_ALgo = "HmacSha1";

		public static void main(String args[]) throws InvalidKeyException, NoSuchAlgorithmException
		{
			String hmac = calculateHmac("HMAC SHA1 Implementation","key",HMAC_ALgo);
			System.out.println("HMAC : "+hmac);
		}
		
		
		
		public static String calculateHmac(String message , String key, String algorithm) throws NoSuchAlgorithmException, InvalidKeyException
		{
			SecretKeySpec signingKey = new SecretKeySpec(key.getBytes(),algorithm);
			Mac mac = Mac.getInstance(algorithm);
			mac.init(signingKey);
			return byteToHex(mac.doFinal(message.getBytes()));
			
		}
		
		public static String byteToHex(byte [] data)
		{
			Formatter formatter = new Formatter();
			for(byte b : data)
			{
				formatter.format("%02x", b);
			}
			return formatter.toString();
		}

}
 
