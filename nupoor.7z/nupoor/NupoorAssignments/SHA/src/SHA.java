

import java.security.MessageDigest;
import java.util.Formatter;

public class SHA 
{
    public static void main(String[] args)throws Exception
    {
    	String message = "Hashing algorithm";
    	
    	
    	MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
    	String hashValue = calculateHash(sha1,message);
    	System.out.println("Hashed value using SHA-1 : "+hashValue);
    	
    	MessageDigest sha224 = MessageDigest.getInstance("SHA-224");
    	hashValue = calculateHash(sha224,message);
    	System.out.println("Hashed value using SHA-224 : "+hashValue);
    	
    	MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
    	hashValue = calculateHash(sha256,message);
    	System.out.println("Hashed value using SHA-256 : "+hashValue);
    	
    	MessageDigest sha384 = MessageDigest.getInstance("SHA-384");
    	hashValue = calculateHash(sha384,message);
    	System.out.println("Hashed value using SHA-384 : "+hashValue);
    	
    	MessageDigest sha512 = MessageDigest.getInstance("SHA-512");
    	hashValue = calculateHash(sha512,message);
    	System.out.println("Hashed value using SHA-512 : "+hashValue);

    	MessageDigest md5 = MessageDigest.getInstance("MD5");
    	hashValue = calculateHash(md5,message);
    	System.out.println("Hashed value using MD5 : "+hashValue);


         
        
        
    	
    	
     }


    
    private static String calculateHash(MessageDigest algorithm , String message)
    {
    	algorithm.update(message.getBytes());
    	byte [] hashData = algorithm.digest();
    	return byteToHex(hashData);
    	
    }

    public static String byteToHex(byte []byteData)
    {
    	Formatter formatter = new Formatter();
    	for(byte b : byteData)
    	{
    		formatter.format("%02x", b);
    	}
    	
    	return formatter.toString();
    }


}