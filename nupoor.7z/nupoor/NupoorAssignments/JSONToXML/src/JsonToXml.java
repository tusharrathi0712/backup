

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public interface JsonToXml {
	
	
	
	public Employees jsonToXml(InputStream in) throws FileNotFoundException, IOException;


//	void toXml(Employees employees, OutputStream out);

}
