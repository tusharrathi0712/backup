
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.fasterxml.jackson.dataformat.xml.JacksonXmlModule;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

public class JsonToXmlImpl implements JsonToXml {

	@Override
	public Employees jsonToXml(InputStream in) throws IOException {

		ObjectMapper jsonmapper = new ObjectMapper();
		TypeFactory typeFactory = jsonmapper.getTypeFactory();
		/*
		 * AnnotationIntrospector introspector = new JaxbAnnotationIntrospector(
		 * mapper.getTypeFactory());
		 * mapper.setAnnotationIntrospector(introspector);
		 */
		jsonmapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		Employees root = new Employees();
		/*
		 * root.Employee = jsonmapper.readValue(in, new
		 * TypeReference<List<Employee>>() { });
		 */ root.Employee = jsonmapper.readValue(in, typeFactory.constructCollectionType(Vector.class, Employee.class));
		JacksonXmlModule xmlModeule = new JacksonXmlModule();
		xmlModeule.setDefaultUseWrapper(false);
		XmlMapper xmlMapper = new XmlMapper(xmlModeule);
		xmlMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		xmlMapper.enable(SerializationFeature.INDENT_OUTPUT);
		System.out.println(xmlMapper.writeValueAsString(root));
		return root;

	}

	// @Override
	/*
	 * public void toXml(Employees root, OutputStream out) {
	 * 
	 * JAXB.marshal(root, out);
	 * 
	 * }
	 */
}
