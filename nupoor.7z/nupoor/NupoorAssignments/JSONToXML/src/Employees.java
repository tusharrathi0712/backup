

import java.util.Vector;

public class Employees {

		

		Vector <Employee>  Employee;
	 
	

		public Vector<Employee> getEmployee() {
			return Employee;
		}

		 public void setEmployee(Vector<Employee> Employee) {
			this.Employee = Employee;
		}

	


	
    	
    	
    	
}
