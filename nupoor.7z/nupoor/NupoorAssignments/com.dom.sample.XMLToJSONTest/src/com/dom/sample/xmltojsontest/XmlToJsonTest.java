package com.dom.sample.xmltojsontest;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.junit.Test;
import org.xml.sax.SAXException;
import net.sf.json.JSONArray;

import com.dom.sample.xmltojson.XmlToJson;
import com.dom.sample.xmltojson.XmlToJsonImpl;

public class XmlToJsonTest {
	
	
	XmlToJson xmlToJson = new XmlToJsonImpl();
	File file = new File("C://Users/nupoork/Desktop/Sample.xml");

	@Test
	public void xmlToJsonConvertTest() throws ParserConfigurationException, SAXException, IOException
	{
		String str = xmlToJson.xmlToJson(file);
		System.out.println(str);
		JSONArray jsonArray = JSONArray.fromObject(str);
		assertTrue(jsonArray.isArray());
	}

}
