package com.dom.sample.xmltojsontest;

import java.io.File;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

import com.dom.sample.xmltojson.XmlToJson;

public class Activator implements BundleActivator {

	

	public void start(BundleContext context) throws Exception {

	}
	
	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext context) throws Exception {
		//System.out.println("Goodbye World!!");
	}


}
