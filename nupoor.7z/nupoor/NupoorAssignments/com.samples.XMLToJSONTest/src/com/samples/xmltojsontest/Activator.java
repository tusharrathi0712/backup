package com.samples.xmltojsontest;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

import com.dom.sample.xmltojson.XmlToJson;

public class Activator implements BundleActivator {

	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#start(org.osgi.framework.BundleContext)
	 */
	ServiceReference reference;

	public void start(BundleContext context) throws Exception {
		//System.out.println("Hello World!!");
		reference = context.getServiceReference(XmlToJson.class.getName());
		
		XmlToJson xmlToJson = (XmlToJson) context.getService(reference);
		xmlToJson.xmlToJson();
		
		//System.out.println("Hello World!!");

	}
	
	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext context) throws Exception {
		//System.out.println("Goodbye World!!");
	}

}
