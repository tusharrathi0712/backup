package com.samples.jsontoxml;

import java.io.IOException;

import org.json.JSONException;

public interface JsonToXml {
	
	
	public String jsonToXml() throws IOException, JSONException;

}
