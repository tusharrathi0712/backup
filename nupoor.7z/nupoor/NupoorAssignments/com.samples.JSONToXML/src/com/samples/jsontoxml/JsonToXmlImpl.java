package com.samples.jsontoxml;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

public class JsonToXmlImpl implements JsonToXml{

	@Override
	public String jsonToXml() throws IOException, JSONException {

		String jsonString = new String(Files.readAllBytes(Paths.get("C://Users/nupoork/Desktop/SampleJson.txt")));
		JSONObject jsonObject = new JSONObject(jsonString);
		/*String xml = "<!DOCTYPE Employees [ "
				+ "!Element Employees (Employee)"
				+ "!Element Employee (type,firstname,lastname,age,email)]>";*/
		String xml = XML.toString(jsonObject);
		return xml;
		
		
	}

}
