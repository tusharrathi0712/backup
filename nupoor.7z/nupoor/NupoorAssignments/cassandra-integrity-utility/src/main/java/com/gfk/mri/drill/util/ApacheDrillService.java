package com.gfk.mri.drill.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.gfk.mri.constants.CassandraTable;
import com.gfk.mri.model.GfkMriDataKey;

public class ApacheDrillService {

	private final String JDBC_DRIVER = "org.apache.drill.jdbc.Driver";
	private final String DB_URL = "jdbc:drill:zk=";

	// private final String USER = "admin";
	// private final String PASS = "admin";

	private String zookeeperIp;
	private String zookeeperPort;
	private String zookeeperClusterName;

	public ApacheDrillService(String zookeeperIp, String zookeeperPort, String zookeeperClusterName)
	{
		super();
		this.zookeeperIp = zookeeperIp;
		this.zookeeperPort = zookeeperPort;
		this.zookeeperClusterName = zookeeperClusterName;
	}

	public Connection createDrillConnection()
	{

		Connection conn = null;

		String jdbcUrl = DB_URL + getZookeeperIp() + ":" + getZookeeperPort() + "/drill/" + getZookeeperClusterName();

		try
		{
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(jdbcUrl);
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		} catch (SQLException e)
		{
			e.printStackTrace();
		}

		return conn;
	}

	public String getZookeeperIp()
	{
		return zookeeperIp;
	}

	public void setZookeeperIp(String zookeeperIp)
	{
		this.zookeeperIp = zookeeperIp;
	}

	public String getZookeeperPort()
	{
		return zookeeperPort;
	}

	public void setZookeeperPort(String zookeeperPort)
	{
		this.zookeeperPort = zookeeperPort;
	}

	public String getZookeeperClusterName()
	{
		return zookeeperClusterName;
	}

	public void setZookeeperClusterName(String zookeeperClusterName)
	{
		this.zookeeperClusterName = zookeeperClusterName;
	}

	public List<GfkMriDataKey> processRequest(String storagePlugin, String workSpace, String filePath)
	{
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;

		List<GfkMriDataKey> resultData = new ArrayList<>();

		try
		{
			conn = createDrillConnection();
			stmt = conn.createStatement();

			String sql = "select columns[1] as `sid`, columns[2] `keyid`, COUNT(*) as `count`  from " + storagePlugin + "." + workSpace + ".`" + filePath + "` group by columns[1], columns[2]";

			
			rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{
				String sid = rs.getString("sid");
				String keyid = rs.getString("keyid");
				String count = rs.getString("count");
				
				resultData.add(new GfkMriDataKey(sid, keyid, count));
			}

		} catch (Exception e)
		{
			e.printStackTrace();
		} finally
		{
			try
			{
				if (rs != null)
					rs.close();
			} catch (SQLException e)
			{
				e.printStackTrace();
			}

			try
			{
				if (stmt != null)
					stmt.close();
			} catch (SQLException e)
			{
				e.printStackTrace();
			}

			try
			{
				if (conn != null)
					conn.close();
			} catch (SQLException e)
			{
				e.printStackTrace();
			}

		}
		
		return resultData;

	}

	public static void main(String[] args)
	{
//		new ApacheDrillService("10.0.6.13", "2181", "drillbits1").processRequest();
//		;
	}

}
