package com.gfk.mri.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.security.CodeSource;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.ResultSetFuture;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.gfk.mri.constants.CassandraTable;
import com.gfk.mri.drill.util.ApacheDrillService;
import com.gfk.mri.exception.GfkMriException;
import com.gfk.mri.model.GfkMriDataKey;
import com.google.common.collect.Sets;

public class CassandraIntegrityUtils {

	private String inputCsvFile;
	private String outputCsvFile;
	private CassandraTable table;
	private String keyspace;
	private String host;
	private String username;
	private String password;
	private Integer driverReadTimeout = 12000;
	private Integer concurrentThreadCount = 50;
	private String zookeeperIp;
	private String zookeeperPort;
	private String zookeeperClusterName;
	private String drillStoragePluginName;
	private String drillWorkSpaceName;
	private String drillRawDataFileName;

	public void initProcess()
	{
		try
		{

			loadProperties();

			long start = new Date().getTime();

			ApacheDrillService apacheDrillService = new ApacheDrillService(getZookeeperIp(), getZookeeperPort(), getZookeeperClusterName());

			List<GfkMriDataKey> drillResult = apacheDrillService.processRequest(getDrillStoragePluginName(), getDrillWorkSpaceName(), getDrillRawDataFileName());

			CassandraService cassandraService = new CassandraService();

			Session session = cassandraService.createSession(Sets.newHashSet(InetAddress.getByName(getHost())), getKeyspace(), getUsername(), getPassword(),
					getDriverReadTimeout());

			generateCountValues(drillResult, session);

			long end = new Date().getTime();

			System.out.println("Completion Time : " + (end - start) / 1000 + " Sec");

		} catch (UnknownHostException e)
		{
			e.printStackTrace();
		}
	}

	public void generateCountValues(List<GfkMriDataKey> drillResult, Session session)
	{
		boolean isLongKey = false;
		double totalcount = 0;
		double recordCount = drillResult.size();
		BufferedReader br = null;

		PreparedStatement ps = null;
		CassandraTable table = getTable();

		switch (table) {
		case RESPONSES:
			ps = session.prepare("select count(d) as c from gfkmri." + CassandraTable.getValue(table) + " where s = ? and d = ?");
			isLongKey = true;

			break;
		case QUESTION_RESPONDENTS:
			ps = session.prepare("select count(q) as c from gfkmri." + CassandraTable.getValue(table) + " where s = ? and q = ?");

			break;

		case RESPONDENT_WEIGHT:
			ps = session.prepare("select count(wt) as c from gfkmri." + CassandraTable.getValue(table) + " where s = ? and wt = ?");
			break;

		default:
			break;
		}

		try
		{
			String outputString = "SID,KeyID,Drill_Count,Cassandra_Count,is_matching\n";
			appendToFile(outputString.toString());
			ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(getConcurrentThreadCount());

			for (GfkMriDataKey gfkMriDataKey : drillResult)
			{
				Runnable worker = new WorkerThread(gfkMriDataKey.getStudyId(), gfkMriDataKey.getKeyId(), gfkMriDataKey.getRespondentCount(), ps,
						isLongKey, session);
				executor.execute(worker);

				totalcount++;

				if (totalcount % 1500 == 0)
				{
					double percent = totalcount / recordCount * 100;
					System.out.println(Math.round(percent) + " % Completed");
				}

				while (executor.getActiveCount() == getConcurrentThreadCount())
				{
					Thread.sleep(50);
				}
			}

			executor.shutdown();
			while (!executor.isTerminated())
			{
			}

			System.out.println("100 % Completed");

		} catch (InterruptedException e)
		{
			e.printStackTrace();
		} finally
		{
			session.getCluster().close();
			session.close();

			try
			{

				if (br != null)
					br.close();

			} catch (IOException ex)
			{

				ex.printStackTrace();

			}
		}

	}


	public synchronized void appendToFile(String data)
	{
		BufferedWriter bw = null;
		FileWriter fw = null;

		try
		{

			File file = new File(getOutputCsvFile());

			// if file doesnt exists, then create it
			if (!file.exists())
			{
				file.createNewFile();
			}

			// true = append file
			fw = new FileWriter(file.getAbsoluteFile(), true);
			bw = new BufferedWriter(fw);

			bw.write(data);

		} catch (IOException e)
		{

			e.printStackTrace();

		} finally
		{

			try
			{

				if (bw != null)
					bw.close();

				if (fw != null)
					fw.close();

			} catch (IOException ex)
			{

				ex.printStackTrace();

			}
		}

	}

	public class WorkerThread implements Runnable {

		private String sid;
		private String keyId;
		private String drillCount;
		private PreparedStatement ps;
		private boolean isLongKey;
		private Session session;

		public WorkerThread(String sid, String keyId, String drillCount, PreparedStatement ps, boolean isLongKey, Session session)
		{
			super();
			this.sid = sid;
			this.keyId = keyId;
			this.drillCount = drillCount;
			this.ps = ps;
			this.isLongKey = isLongKey;
			this.session = session;
		}

		@Override
		public void run()
		{

			int count = 0;
			int batchsize = 1500;
			StringBuffer outputString = new StringBuffer("");

			long start = new Date().getTime();

			ResultSetFuture future = null;

			try
			{
				if (isLongKey)
					future = session.executeAsync(ps.bind(Integer.parseInt(sid), Long.parseLong(keyId)));
				else
					future = session.executeAsync(ps.bind(Integer.parseInt(sid), Integer.parseInt(keyId)));

				while (!future.isDone())
				{
					wait(50);
				}

				ResultSet results = future.get();

				for (Row row : results)
				{

					count++;
					if (count >= batchsize)
					{
						appendToFile(outputString.toString());

						outputString = new StringBuffer("");
					}

					Long CassandraCount = row.getLong("c");
					Long drillCnt = Long.parseLong(drillCount);

					String maching = CassandraCount.equals(drillCnt) ? "Y" : "N";

					outputString.append(sid + "," + keyId + "," + drillCnt + "," + CassandraCount + "," + maching + "\n");

				}

				appendToFile(outputString.toString());

			} catch (NumberFormatException e)
			{
				System.out.println("Study_ID: " + sid + " |  key_ID: " + keyId);
				long end = new Date().getTime();
				System.out.println("Timeout After : " + (end - start) + " ms");
				outputString.append(sid + "," + keyId + "," + drillCount + "," + "0" + "," + "E" + "\n");
				e.printStackTrace();
			} catch (InterruptedException e)
			{
				System.out.println("Study_ID: " + sid + " |  key_ID: " + keyId);
				long end = new Date().getTime();
				System.out.println("Timeout After : " + (end - start) + " ms");
				outputString.append(sid + "," + keyId + "," + drillCount + "," + "0" + "," + "E" + "\n");
				e.printStackTrace();
			} catch (ExecutionException e)
			{
				System.out.println("Study_ID: " + sid + " |  key_ID: " + keyId);
				long end = new Date().getTime();
				System.out.println("Timeout After : " + (end - start) + " ms");
				outputString.append(sid + "," + keyId + "," + drillCount + "," + "0" + "," + "E" + "\n");
				e.printStackTrace();
			} finally
			{

			}

		}

		private void wait(int timeInMilliSec)
		{
			try
			{
				Thread.sleep(timeInMilliSec);
			} catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}

	}

	public boolean isInteger(String str)
	{

		if (str == null || str.equals(""))
			return false;

		int size = str.length();

		for (int i = 0; i < size; i++)
		{
			if (!Character.isDigit(str.charAt(i)))
			{
				return false;
			}
		}

		return size > 0;
	}

	private boolean loadProperties()
	{

		InputStream is = null;
		Properties prop = null;

		try
		{
			CodeSource src = CassandraIntegrityUtils.class.getProtectionDomain().getCodeSource();
			if (src != null)
			{
				URL url = new URL(src.getLocation(), "integrity_config.properties");

				prop = new Properties();
				is = new FileInputStream(new File(url.getPath()));
				prop.load(is);

				setHost(prop.getProperty("cassandra.host.ip"));
				setUsername(prop.getProperty("cassandra.username"));
				setPassword(prop.getProperty("cassandra.password"));
				setKeyspace(prop.getProperty("cassandra.keyspace.name"));
				String tableName = prop.getProperty("cassandra.table.name");
				CassandraTable table = CassandraTable.getTableFromString(tableName);
				if (table == null)
				{
					throw new GfkMriException("Cassandra Table Name is not valid : " + tableName);
				}
				setTable(table);

				setZookeeperIp(prop.getProperty("drill.zookeeper.ip"));
				setZookeeperPort(prop.getProperty("drill.zookeeper.port"));
				setZookeeperClusterName(prop.getProperty("drill.zookeeper.cluster.name"));
				setDrillStoragePluginName(prop.getProperty("drill.storage.plugin.name"));
				setDrillWorkSpaceName(prop.getProperty("drill.workspace.name"));
				setDrillRawDataFileName(prop.getProperty("drill.rawdata.file.name"));

				
				String outputDirectoryPath = prop.getProperty("output.csv.directory.path");
				File outputDirectory = new File(outputDirectoryPath);
				if (outputDirectory.exists() && !outputDirectory.isDirectory())
				{
					throw new GfkMriException("Output directory path is not valid : " + outputDirectoryPath);
				} else
				{
					outputDirectory.mkdirs();
				}

				String outputFile = outputDirectoryPath + "/outputData_" + CassandraTable.getValue(getTable()) + ".csv";
				setOutputCsvFile(outputFile);

				String threadCount = prop.getProperty("concurrent.thread.count");
				if (isInteger(threadCount))
				{
					setConcurrentThreadCount(Integer.parseInt(threadCount));
				}

				String driverTimeout = prop.getProperty("driver.read.timeout.millis");
				if (isInteger(driverTimeout))
				{
					setDriverReadTimeout(Integer.parseInt(driverTimeout));
				}

			} else
			{
				System.out.println("Failed to load properties file ...");
				return false;
			}
		} catch (MalformedURLException e)
		{
			e.printStackTrace();
		} catch (FileNotFoundException e)
		{
			e.printStackTrace();
		} catch (IOException e)
		{
			e.printStackTrace();
		} catch (GfkMriException e)
		{
			e.printStackTrace();
		}

		return true;

	}

	public String getInputCsvFile()
	{
		return inputCsvFile;
	}

	public void setInputCsvFile(String inputCsvFile)
	{
		this.inputCsvFile = inputCsvFile;
	}

	public String getOutputCsvFile()
	{
		return outputCsvFile;
	}

	public void setOutputCsvFile(String outputCsvFile)
	{
		this.outputCsvFile = outputCsvFile;
	}

	public String getHost()
	{
		return host;
	}

	public void setHost(String host)
	{
		this.host = host;
	}

	public String getKeyspace()
	{
		return keyspace;
	}

	public void setKeyspace(String keyspace)
	{
		this.keyspace = keyspace;
	}

	public String getUsername()
	{
		return username;
	}

	public void setUsername(String username)
	{
		this.username = username;
	}

	public String getPassword()
	{
		return password;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}

	public Integer getDriverReadTimeout()
	{
		return driverReadTimeout;
	}

	public void setDriverReadTimeout(Integer driverReadTimeout)
	{
		this.driverReadTimeout = driverReadTimeout;
	}

	public Integer getConcurrentThreadCount()
	{
		return concurrentThreadCount;
	}

	public void setConcurrentThreadCount(Integer concurrentThreadCount)
	{
		this.concurrentThreadCount = concurrentThreadCount;
	}

	public String getZookeeperIp()
	{
		return zookeeperIp;
	}

	public void setZookeeperIp(String zookeeperIp)
	{
		this.zookeeperIp = zookeeperIp;
	}

	public String getZookeeperPort()
	{
		return zookeeperPort;
	}

	public void setZookeeperPort(String zookeeperPort)
	{
		this.zookeeperPort = zookeeperPort;
	}

	public String getZookeeperClusterName()
	{
		return zookeeperClusterName;
	}

	public void setZookeeperClusterName(String zookeeperClusterName)
	{
		this.zookeeperClusterName = zookeeperClusterName;
	}

	public String getDrillStoragePluginName()
	{
		return drillStoragePluginName;
	}

	public void setDrillStoragePluginName(String drillStoragePluginNam)
	{
		this.drillStoragePluginName = drillStoragePluginNam;
	}

	public String getDrillWorkSpaceName()
	{
		return drillWorkSpaceName;
	}

	public void setDrillWorkSpaceName(String drillWorkSpaceName)
	{
		this.drillWorkSpaceName = drillWorkSpaceName;
	}

	public String getDrillRawDataFileName()
	{
		return drillRawDataFileName;
	}

	public void setDrillRawDataFileName(String drillRawDataFileName)
	{
		this.drillRawDataFileName = drillRawDataFileName;
	}

	public CassandraTable getTable()
	{
		return table;
	}

	public void setTable(CassandraTable table)
	{
		this.table = table;
	}

	public static void main(String[] args)
	{
		CassandraIntegrityUtils cassandraIntegrityUtils = new CassandraIntegrityUtils();
		cassandraIntegrityUtils.initProcess();
	}

}
