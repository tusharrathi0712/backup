package com.gfk.mri.model;

public class GfkMriDataKey {
	private String studyId;
	private String keyId;
	private String respondentCount;
	
	
	public GfkMriDataKey(String studyId, String keyId, String respondentCount)
	{
		super();
		this.studyId = studyId;
		this.keyId = keyId;
		this.respondentCount = respondentCount;
	}
	
	
	public String getStudyId()
	{
		return studyId;
	}
	public void setStudyId(String studyId)
	{
		this.studyId = studyId;
	}
	public String getKeyId()
	{
		return keyId;
	}
	public void setKeyId(String keyId)
	{
		this.keyId = keyId;
	}
	public String getRespondentCount()
	{
		return respondentCount;
	}
	public void setRespondentCount(String respondentCount)
	{
		this.respondentCount = respondentCount;
	}
	
	

}
