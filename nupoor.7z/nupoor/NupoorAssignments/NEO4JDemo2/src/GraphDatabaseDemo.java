import java.io.File;

import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Relationship;
import org.neo4j.graphdb.ResourceIterator;
import org.neo4j.graphdb.Transaction;
import org.neo4j.graphdb.factory.GraphDatabaseFactory;
import org.neo4j.graphdb.index.Index;
import org.neo4j.graphdb.index.IndexManager;

public class GraphDatabaseDemo {

	public GraphDatabaseDemo() {
	}

	private final static File DB_PATH = new File("D:/Neo4jDatabase");
	
	public static void main(String [] args)
	{

		GraphDatabaseService graphDB = new GraphDatabaseFactory().newEmbeddedDatabase(DB_PATH);
		try (Transaction tx = graphDB.beginTx()) {
			graphDB.schema().indexFor(Labels.Genre).on("id").create();
			graphDB.schema().indexFor(Labels.Keyword).on("id").create();
			graphDB.schema().indexFor(Labels.Movie).on("id").create();
			graphDB.schema().indexFor(Labels.Person).on("id").create();
			tx.success();
		}
		Transaction tx = graphDB.beginTx();
		String query = "LOAD CSV WITH HEADERS FROM \"file:///D:/NEO4JCSVData/genre_node.csv\" as input FIELDTERMINATOR \";\" CREATE (gn:Genre {id: toInt(input.Genre_id), name: input.name})";
		graphDB.execute(query);
		ResourceIterator<Node> genre = graphDB.findNodes(Labels.Genre);
		
		query = "LOAD CSV WITH HEADERS FROM \"file:///D:/NEO4JCSVData/person_node.csv\" as input FIELDTERMINATOR \";\" CREATE (person:Person {id: toInt(input.Person_id), name: input.name, born: toInt(input.born), poster_image: input.poster_image})";
		graphDB.execute(query);
		ResourceIterator<Node> Person = graphDB.findNodes(Labels.Person);
		
		query = "LOAD CSV WITH HEADERS FROM \"file:///D:/NEO4JCSVData/movie_node.csv\" as input FIELDTERMINATOR \";\" CREATE (mv:Movie {id: toInt(input.Movie_id), title: input.title, tagline: input.tagline, summary: input.summary, poster_image: input.poster_image, duration: toInt(input.duration), rated: input.rated})";
		graphDB.execute(query);
		ResourceIterator<Node> Movie = graphDB.findNodes(Labels.Movie);
		
		query = "LOAD CSV WITH HEADERS FROM \"file:///D:/NEO4JCSVData/keyword_node.csv\" as input FIELDTERMINATOR \";\" CREATE (keyword:Keyword {id: toInt(input.Keyword_id), name: input.name})";
		graphDB.execute(query);
		ResourceIterator<Node> keyword = graphDB.findNodes(Labels.Movie);
		
		
		query = "LOAD CSV WITH HEADERS FROM \"file:///D:/NEO4JCSVData/has_keyword_rels.csv\" as input FIELDTERMINATOR \";\" MATCH (mv:Movie  {id: toInt(input.Movie_id)}), (keyword:Keyword {id: toInt(input.Keyword_id)}) CREATE (mv)-[has_keyword: HAS_KEYWORD]->(keyword)";
		graphDB.execute(query);
		
		query = "LOAD CSV WITH HEADERS FROM \"file:///D:/NEO4JCSVData/acted_in_rels.csv\" as input FIELDTERMINATOR \";\" MATCH (person:Person  {id: toInt(input.Person_id)}), (mv:Movie {id: toInt(input.Movie_id)}) CREATE (person)-[acted_in: ACTED_IN {role: input.role}]->(mv)";
		graphDB.execute(query);
		
		query = "LOAD CSV WITH HEADERS FROM \"file:///D:/NEO4JCSVData/directed_rels.csv\" as input FIELDTERMINATOR \";\" MATCH (person:Person  {id: toInt(input.Person_id)}), (mv:Movie {id: toInt(input.Movie_id)}) CREATE (person)-[directed: DIRECTED]->(mv)";
		graphDB.execute(query);
		
		query = "LOAD CSV WITH HEADERS FROM \"file:///D:/NEO4JCSVData/produced_rels.csv\" as input FIELDTERMINATOR \";\" MATCH (person:Person  {id: toInt(input.Person_id)}), (mv:Movie {id: toInt(input.Movie_id)}) CREATE (person)-[produced: PRODUCED]->(mv)";
		graphDB.execute(query);
		
		query = "LOAD CSV WITH HEADERS FROM \"file:///D:/NEO4JCSVData/writer_of_rels.csv\" as input FIELDTERMINATOR \";\" MATCH (person:Person  {id: toInt(input.Person_id)}), (mv:Movie {id: toInt(input.Movie_id)}) CREATE (person)-[writer_of: WRITER_OF]->(mv)";
		graphDB.execute(query);
		
		query = "LOAD CSV WITH HEADERS FROM \"file:///D:/NEO4JCSVData/has_genre_rels.csv\" as input FIELDTERMINATOR \";\" MATCH (mv:Movie {id: toInt(input.Movie_id)}),(gn:Genre {id: toInt(input.Genre_id)}) CREATE (mv)-[has_genre: HAS_GENRE]->(gn)";
		graphDB.execute(query);
		
		
		
		
		
		
		
		
		
		tx.success();
		
		
		
	}
			

	/*public static Relationship seeMovie( Node user, Node movie, int stars )
	{
	    Relationship relationship = user.createRelationshipTo( movie, RelationshipTypes.HAS_SEEN );
	    relationship.setProperty( "stars", stars );
	    return relationship;
	}*/
}
