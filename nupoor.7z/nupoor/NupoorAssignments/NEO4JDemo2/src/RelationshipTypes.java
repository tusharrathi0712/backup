import org.neo4j.graphdb.RelationshipType;

public enum RelationshipTypes implements RelationshipType {
	
	
	HAS_KEYWORD,HAS_GENRE,DIRECTED,PRODUCED,ACTED_IN,WRITER_OF;

}
