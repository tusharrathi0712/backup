import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.KeyStore.PasswordProtection;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SignatureException;
import java.security.UnrecoverableEntryException;
import java.security.cert.Certificate;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.util.Date;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.bouncycastle.jce.X509Principal;
import org.bouncycastle.x509.X509V3CertificateGenerator;

public class RSAKeyStore {

	private static final byte[] keyValue = { 'a', 'b', 'c', 'v', 'd', 'f', 'g', 'f', 'h', 'j', 't', 'g', 'j', 'k', 'h',
			'f' };

	public static void main(String[] args) throws NoSuchAlgorithmException, KeyStoreException, InvalidKeySpecException,
			CertificateException, IOException, InvalidKeyException, NoSuchProviderException, SignatureException,
			NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException,
			UnrecoverableEntryException {
		String keyStoreFile = "C://Users/nupoork/Desktop/RSA.jks";
		String password = "nupoor";
		
		
		

		KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
		keyPairGenerator.initialize(2048);
		KeyPair keyPair = keyPairGenerator.generateKeyPair();

		PublicKey publicKey = keyPair.getPublic();
		PrivateKey privateKey = keyPair.getPrivate();
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");

		RSAPublicKeySpec rsaPublicKey = keyFactory.getKeySpec(publicKey, RSAPublicKeySpec.class);
		RSAPrivateKeySpec rsaPrivateKey = keyFactory.getKeySpec(privateKey, RSAPrivateKeySpec.class);
		privateKey = keyFactory
				.generatePrivate(new RSAPrivateKeySpec(rsaPrivateKey.getModulus(), rsaPrivateKey.getPrivateExponent()));
		publicKey = keyFactory
				.generatePublic(new RSAPublicKeySpec(rsaPublicKey.getModulus(), rsaPublicKey.getPublicExponent()));

		//KeyStore keyStore = createKeyStore(keyStoreFile, password);
		Key secretKey = new SecretKeySpec(keyValue, "AES");

		X509Certificate certificate = generateCertificate(privateKey, publicKey);
		Certificate[] certificates = new Certificate[1];
		certificates[0] = certificate;

		File fl = new File(keyStoreFile);
		KeyStore keyStore = KeyStore.getInstance("JKS");
		PasswordProtection keyPassword = new PasswordProtection(password.toCharArray());

		if (fl.exists()) {

			keyStore.load(new FileInputStream(keyStoreFile), password.toCharArray());

			
		} else {
			keyStore.load(null, null);
			//keyStore.store(new FileOutputStream(keyStoreFile), password.toCharArray());
			KeyStore.PrivateKeyEntry privateKeyEntry = new KeyStore.PrivateKeyEntry(privateKey, certificates);			
			keyStore.setCertificateEntry("myCertificate", certificate);
			keyStore.setEntry("myPrivateKey", privateKeyEntry, keyPassword);
			keyStore.store(new FileOutputStream(keyStoreFile), password.toCharArray());

		}
		
		
		byte[] p = { 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a' };
		String plainText = new String(p);
		System.out.println(plainText);
		byte[] ct = encryption(secretKey, plainText);
		String cipherText = new String(ct);
		System.out.println("cipher text in bytes : " + cipherText);
		byte[] plainText1 = decryption(secretKey, ct);
		String str = new String(plainText1);
		System.out.println("plainText : " + str);

		byte[] wrap = wrapKey(keyStore.getCertificate("myCertificate").getPublicKey(), secretKey);
		// Key unWrap = unWrapKey(privateKey, wrap);
		Key unWrap = unWrapKey(keyStore.getKey("myPrivateKey", password.toCharArray()), wrap);

		System.out.println(" " + new String(unWrap.getEncoded()));
		if (new String(unWrap.getEncoded()).equals(new String(secretKey.getEncoded()))) {
			System.out.println("SAME");
		}

		 KeyStore.Entry entry = keyStore.getEntry("myPrivateKey", keyPassword);
		 PrivateKey keyFound = ((KeyStore.PrivateKeyEntry)entry).getPrivateKey();
		 System.out.println("found key : "+keyFound);
		 
		 PublicKey Centry = keyStore.getCertificate("myCertificate").getPublicKey();
		 //PrivateKey keyFound = ((KeyStore.PrivateKeyEntry)entry).getPrivateKey();
		 System.out.println("found key : "+Centry);
		 

	}

	private static byte[] encryption(Key secretKey, String plainText)
			throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException,
			BadPaddingException, UnsupportedEncodingException, InvalidAlgorithmParameterException {
		Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
		byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);

		cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivParameterSpec);

		byte[] encryptedBytes = cipher.doFinal(plainText.getBytes());
		return encryptedBytes;

	}

	private static byte[] decryption(Key secretKey, byte[] cipherText)
			throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException,
			BadPaddingException, UnsupportedEncodingException, InvalidAlgorithmParameterException {
		Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
		byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
		cipher.init(Cipher.DECRYPT_MODE, secretKey, ivParameterSpec);
		byte[] decryptedBytes = cipher.doFinal(cipherText);

		return decryptedBytes;
	}

	/*private static KeyStore createKeyStore(String f, String password)
			throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException {
		File fl = new File(f);
		KeyStore keyStore = KeyStore.getInstance("JKS");
		if (fl.exists()) {
			keyStore.load(new FileInputStream(f), password.toCharArray());
		} else {
			keyStore.load(null, null);
			keyStore.store(new FileOutputStream(f), password.toCharArray());
		}
		return keyStore;
	}*/

	private static byte[] wrapKey(PublicKey publicKey, Key secretKey)
			throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException {

		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.WRAP_MODE, publicKey);
		byte[] wrapped = cipher.wrap(secretKey);
		return wrapped;

	}

	private static Key unWrapKey(Key privateKey, byte[] unWrp) throws NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException {

		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.UNWRAP_MODE, privateKey);
		Key unWrapped = cipher.unwrap(unWrp, "AES", Cipher.SECRET_KEY);
		return unWrapped;

	}

	private static X509Certificate generateCertificate(PrivateKey priateKey, PublicKey publicKey)
			throws CertificateEncodingException, InvalidKeyException, IllegalStateException, NoSuchAlgorithmException,
			SignatureException {
		X509V3CertificateGenerator cert = new X509V3CertificateGenerator();
		cert.setSerialNumber(BigInteger.valueOf(1));
		cert.setSubjectDN(new X509Principal("cn=nupoor"));
		cert.setIssuerDN(new X509Principal("cn=nupoor"));
		cert.setPublicKey(publicKey);
		cert.setNotBefore(new Date(16 / 3 / 2015));
		cert.setNotAfter(new Date(17 / 3 / 2015));
		cert.setSignatureAlgorithm("SHA1WithRSA");
		return cert.generate(priateKey);

	}
}
