#!/bin/bash
TAG_KEY=$1
INFLUXDB=$2
DBNAME=$3
project_name=$4
tail -n0 -F $project_name/summary.log| while read line
  do
    if echo $line | grep -q 'summary +'; then
      echo $line
      Sampler="$(echo $line | sed 's/^.*summary +//' | sed 's/in.*//' | tr -d " ")"
      Throughput="$(echo $line | sed 's/^.*in.*=//' | sed 's/\/s.*//' | tr -d " ")"
      AverageResponseTime="$(echo $line | sed 's/^.*Avg://' | sed 's/Min:.*//' | tr -d " ")"
      MinResponseTime="$(echo $line | sed 's/^.*Min://' | sed 's/Max:.*//' | tr -d " ")"
      MaxResponseTime="$(echo $line | sed 's/^.*Max://' | sed 's/Err:.*//' | tr -d " ")"
      Error="$(echo $line | sed 's/^.*(//' | sed 's/\%).*//' | tr -d " ")"
      curl -i -XPOST "http://$INFLUXDB/write?db=$DBNAME" --data-binary "jmeter_run_report2,jmx="$TAG_KEY" sampler="$Sampler",throughput="$Throughput",average_response_time="$AverageResponseTime",min_response_time="$MinResponseTime",max_response_time="$MaxResponseTime",error_perc="$Error
    fi
  done

