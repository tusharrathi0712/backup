#!/bin/bash
constant=$1
studyCount=$2
scale=$3
tableName=$scale'_responses'
echo "StudyID DataPointCount Range" >> /home/ubuntu/gfkmri/InputData/dataPointsPerStudy.txt
range=( 0 25000 50000 100000 150000 200000 250000 300000 350000 400000 450000 500000 550000 )
to=0;
    
       for from in ${range[@]};
	   do
	   to=$((to+1))
	   if [ "${#range[@]}" -ne "${to}" ]; then
	    
		echo $to
		
     /opt/vertica/bin/vsql -At -h 10.0.6.6 -w cybage@123 -d gfkmri -U dbadmin -c "Insert into responses_count_master_range (SID,COUNT_RESPONSES,range) select SID,count(DID),'${range[$to]}' from responses_count_master where COUNT BETWEEN '$from' and '${range[$to]}' group by SID;COMMIT;"
	 
	  fi
	  done
	  perStudyDP=$((constant / studyCount))
	 
	  totalCount=`/opt/vertica/bin/vsql -At -h 10.0.6.6 -w cybage@123 -d gfkmri -U dbadmin -c "select SUM(COUNT_RESPONSES) FROM responses_count_master_range;"`
	 
	/opt/vertica/bin/vsql -At -h 10.0.6.6 -w cybage@123 -d gfkmri -U dbadmin -c "create table IF NOT EXISTS $tableName (SID INT,DID INT,COUNT INT,range INT);"	 

	
	while read line           
	do
		if [ ! -z "$line" ];
		then
		    from=0 
			for r in ${range[@]};
			do
			if [ "$r" -ne 0 ];
			then
				count=`/opt/vertica/bin/vsql -At -h 10.0.6.6 -w cybage@123 -d gfkmri -U dbadmin -c "select SUM(COUNT_RESPONSES) FROM responses_count_master_range where range='$r';"`
				
				if [ ! -z "$count" ];
				then
					perOnTotalCount=$(echo "scale=7; ($count/$totalCount)*100" | bc)
					dataPCountPerStudy=$(echo "($perOnTotalCount*$perStudyDP)/100" | bc)
					

					echo $perOnTotalCount
					echo $perOnTotalCount
					
					if [ "$dataPCountPerStudy" -lt 1 ];
					then 
						dataPCountPerStudy=1
						fi
					
										
					/opt/vertica/bin/vsql -At -h 10.0.6.6 -w cybage@123 -d gfkmri -U dbadmin -c "Insert into $tableName (SID,DID,COUNT,range) select SID,DID,COUNT,'$r' from responses_count_master where SID='$line' and COUNT >= '${range[$from]}' and  COUNT < '$r'  limit '$dataPCountPerStudy';COMMIT;"
					
					#countDID=`/opt/vertica/bin/vsql -At -h 10.0.6.6 -w cybage@123 -d gfkmri -U dbadmin -c "select COUNT() from responses_count_master where SID='$line';"`
					#if [ ! -z "$countDID" ];
					#then
																
						#if [ "$countDID" -ge "${range[$from]}" ] && [ "$countDID" -lt "$r" ];
						#then
						#/opt/vertica/bin/vsql -At -h 10.0.6.6 -w cybage@123 -d gfkmri -U dbadmin -c "Insert into $tableName (SID,DID,COUNT,range) select SID,DID,COUNT,'$r' from responses_count_master where SID='$line' limit '$dataPCountPerStudy';COMMIT;"
						
					#	fi
					#fi
					from=$((from+1))
				fi
			fi
			done
		fi
	done < studyId.txt
	
/opt/vertica/bin/vsql -At -h 10.0.6.6 -w cybage@123 -d gfkmri -U dbadmin -o /home/ubuntu/gfkmri/InputData/dataPointsPerStudy.txt -c "select SID,COUNT(DID),range FROM $tableName group by SID,range;"
	
/opt/vertica/bin/vsql -At -h 10.0.6.6 -w cybage@123 -d gfkmri -U dbadmin -o /home/ubuntu/gfkmri/InputData/responses_scale3.csv -c "select SID,DID,COUNT FROM $tableName order by COUNT;"