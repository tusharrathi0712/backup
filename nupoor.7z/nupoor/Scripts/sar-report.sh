#!/bin/bash
###This Script Useful for following puposes: 
#	1. Monitor defined Hosts and Generate SAR Report + Summary report per Run.
#	2. Generate SAR Summary Report from already executed SAR LOG files.
#	3. Install SYSSTAT on defined Hosts. 
############################################################################################################

 
###	Provide below 2 parameters to the script while monitoring defined Hosts. Variables to start SAR
declare -i Time=$1				# Define total duration to execute SAR on defined HOST machines.
FileName=$2					# Define Name of the SAR Files for selected execution cycle. 
declare -i Interval=2			# Define Time interval (In second) to collect SAR data from defined HOST machines.

#Variables to store and extract SAR Log file result 
User='ec2-user'  #define User name to login to the Host machines.
project_home=$3

echo projectHome $project_home
ResultFolder=$project_home/sar_report	# Define path to generate SAR report.
echo $ResultFolder
Path="/home/ec2-user/sarResults"		# Define path of the HOST machines to generate and copy SAR report.
echo "path $Path"
SARPath=$project_home			# Define path of the SAR Files.
PEM_FILE="GFK_MRI_CASSANDRA_KEY.pem"                     # The full name of the pem file you downloaded from your Amazon account. Usualy .pem from AWS but you could generate your own and name it what you want.
PEM_PATH="/home/ec2-user"             # The path to your pem file
#PEM_FILE="VPCTest.pem"			# The full name of the pem file you downloaded from your Amazon account. Usualy .pem from AWS but you could generate your own and name it what you want.
#PEM_PATH="/home/ubuntu"                	# The path to your pem file
SARREPORT_ONLY="false"			# Generate SAR Summary report from existing SAR result for defined Host machine and defined SAR file name in 
SYSSTATE_INSTALL="false"			# Install SYSSTATE on all Hosts machine defined in the HOSTFILE.txt. By default value is False.
SYSSTAT_VERSION="sysstat-10.2.0" 		# The version of SYSSTAT to be used. Must be the full name used in the dir structure. Does not work for versions prior to 10.2.0.
HOSTOS="Ubuntu"                                  #$(lsb_release -i | sed 's/Distributor ID://' | tr -d "\t")
				# Name of the OS of Hosts defined in the HOSTFILE.txt. Value should be either "ec2-user" or "CentOS".
PASSWDLESS="false"				# Define to generate password less login to Remote hosts. Set to True and execute script without parameters for passwordless login. 

REMOTE_PORT=22

# REMOTE_HOSTS : Script reads list of hostnames to run the test. 
REMOTE_HOSTS=
# SAR RESULT FILE
# Define file name if SAR Summary to be created from existing log files. 
# Must be a comma-separated list, like this: SAR_FILENAME="test_run_1L,test_run_2L"
#SAR_FILENAME="Test_Report"
sh $project_home/clear.sh $project_home

########## ########## ########## SAR SUMMARY FUNCTIONS ########## ########## ########## 
sarSummary()
{
	# =========================== Logic to calculate Summary Data ===========================
	
	if [ "$1" = "$CPUFILE" ]
	then 
		######################################### CPU #################################################
		##########			sarSummary $CPUFILE "%user" "%system" "%iowait" "%idle"			##########
		###############################################################################################
		#### CPU related Code: Delete top 3 lines and bottom one line and add data in new file
		
		# Files to store CPU Columns data
		cpuidle=$ResultFolder/cpuidle.log
		cpuuser=$ResultFolder/cpuuser.log
		cpuiowait=$ResultFolder/cupiowait.log
		cpusystem=$ResultFolder/cpusystem.log
		cputemp=$ResultFolder/cputemp.log
		# Create empty file
		cp /dev/null $cpuidle
		cp /dev/null $cpuuser
		cp /dev/null $cpuiowait
		cp /dev/null $cpusystem

		cpuiowaitvar1=""
		cpuiowaitvar=""		
		cpuuservar=""  # >>> Since it is used for Heading of the file
		cpuuservar1=""
		cpusystemvar=""
		cpusystemvar1=""		
		cpuidlevar=""
		cpuidlevar1=""

		cp /dev/null $cputemp											# Generate File with SAR Result row
		cat $1 | tail -n +3 | head -n -1 >  $ResultFolder/cpu.txt.new && mv $ResultFolder/cpu.txt.new $ResultFolder/cputemp.log	# delete top 2 file n bottom 1 line		
		
		# Read first column line from log file in the abc array and store column name in the variable. 
		abc=()				
		IFS=' ' abc=($(head -1 $ResultFolder/cputemp.log))  #Read first line in the Array 

		i=0
		for ((i=0; i< ${#abc[@]}; i++))
		do		
			#Check column location
			if [ "${abc[$i]}" = "$2" ]  #%user column name
			then
				CpuUsercol=$i
			elif [ "${abc[$i]}" = "$3" ]  #%system column name
			then
				CpuSystemcol=$i
			elif [ "${abc[$i]}" = "$4" ]  #%IOWait column name
			then
				CpuIOWaitcol=$i
			elif [ "${abc[$i]}" = "$5" ]  #%Idle column name
			then
				CpuIdlecol=$i		
			fi				
		done
		
		#Remove last line from the file 
		cat $ResultFolder/cputemp.log | tail -n +2 >  $ResultFolder/cpu.txt.new && mv $ResultFolder/cpu.txt.new $ResultFolder/cputemp.log

		#echo "After Reading:" | cat $ResultFolder/cputemp.log		
		while read line
		do
			IFS=' ' abc=($line)  #(cat $ResultFolder/cputemp.log))
			#echo "Array: "${abc[@]}""
			echo "${abc[$CpuUsercol]}" >> $cpuuser
			echo "${abc[$CpuSystemcol]}" >> $cpusystem	
			echo "${abc[$CpuIOWaitcol]}" >> $cpuiowait
			echo "${abc[$CpuIdlecol]}" >> $cpuidle						
		done < $ResultFolder/cputemp.log

		#################### Read line from NW file and calculate Max, Min and Avg #####################

		##########CPU %User data

		cpuuservar1=$(awk '{ if ($1>max) {max=$1; line=$0} } END{print line}' $cpuuser)  #Max
		cpuuservar=$server$','$cpuuservar1

		cpuuservar1=$(awk 'min=="" || $1 < min {min=$1; minline=$0}; END{ print minline}' $cpuuser)  #Min
		cpuuservar=$cpuuservar$','$cpuuservar1

		cpuuservar1=$(awk '{s+=$1} END{print (s/(NR))}' $cpuuser)   # Average
		cpuuservar=$cpuuservar$','$cpuuservar1','"%User"
		
		##########CPU %System data

		cpusystemvar1=$(awk '{ if ($1>max) {max=$1; line=$0} } END{print line}' $cpusystem)  #Max
		cpusystemvar=$server$','$cpusystemvar1

		cpusystemvar1=$(awk 'min=="" || $1 < min {min=$1; minline=$0}; END{ print minline}' $cpusystem)  #Min
		cpusystemvar=$cpusystemvar$','$cpusystemvar1

		cpusystemvar1=$(awk '{s+=$1} END{print (s/(NR))}' $cpusystem)   # Average
		cpusystemvar=$cpusystemvar$','$cpusystemvar1','"%System"
		
		##########CPU %IOWAIT data

		cpuiowaitvar1=$(awk '{ if ($1>max) {max=$1; line=$0} } END{print line}' $cpuiowait)  #Max
		cpuiowaitvar=$server$','$cpuiowaitvar1

		cpuiowaitvar1=$(awk 'min=="" || $1 < min {min=$1; minline=$0}; END{ print minline}' $cpuiowait)  #Min
		cpuiowaitvar=$cpuiowaitvar$','$cpuiowaitvar1

		cpuiowaitvar1=$(awk '{s+=$1} END{print (s/(NR))}' $cpuiowait)   # Average
		cpuiowaitvar=$cpuiowaitvar$','$cpuiowaitvar1','"%IOWait"

		##########CPU Idle Values: Maximum CPU Utilization
		
		cpuidlevar1=$(awk '{ if ($1>max) {max=$1; line=$0} } END{print line}' $cpuidle)  #Minimum CPU Utilization
		cpuidlevar=$server$','$cpuidlevar1

		cpuidlevar1=$(awk 'min=="" || $1 < min {min=$1; minline=$0}; END{ print minline}' $cpuidle)
		cpuidlevar=$cpuidlevar$','$cpuidlevar1	
		
		cpuidlevar1=$(awk '{s+=$1} END{print s/(NR)}' $cpuidle)	#Average CPU Utilization
		cpuidlevar=$cpuidlevar$','$cpuidlevar1','"%Idle"
		
		###### Add Min, Max and Average values for a Server in the Summary file 
		echo $cpuuservar >> $CPUSUMFile
		echo $cpusystemvar >> $CPUSUMFile
		echo $cpuiowaitvar >> $CPUSUMFile
		echo $cpuidlevar >> $CPUSUMFile
		
	elif [ "$1" = "$RAMFILE" ]
	then 
		######################################### RAM #################################################
		##########		$sarSummary $RAMFILE "kbmemused" "%memused"			##########
		###############################################################################################
			
		#### Delete top 3 lines and bottom one line and add data in new file
		ramsumfile=$ResultFolder/ramsumfile.log
		rampersumfile=$ResultFolder/rampersumfile.log
		ramtemp=$ResultFolder/ramtemp.log
		# Create empty file
		cp /dev/null $ramsumfile
		cp /dev/null $rampersumfile
		
		ramsumvar1=""
		ramsumvar=""		
		rampersumvar1=""
		rampersumvar=""
		
		# Generate File with SAR Result row 
		
		cp /dev/null $ramtemp				# Generate File with SAR Result row
		cat $1 | tail -n +3 | head -n -1 >  $ResultFolder/ram.txt.new && mv $ResultFolder/ram.txt.new $ResultFolder/ramtemp.log  # delete top 2 file n bottom 1 line

		abc=()		
		IFS=' ' abc=($(head -1  $ResultFolder/ramtemp.log)) # Add Column Name in the abc Array		
		i=0
		for ((i=0; i< ${#abc[@]}; i++))
		do			
			#Check column location
			if [ "${abc[$i]}" = "$2" ]  #kbmemused  column name
			then
				MemUsecol=$i
			elif [ "${abc[$i]}" = "$3" ]  #%memused column name
			then
				MemperUsecol=$i
			fi				
		done
		# Read line from RAM file and calculate Max, Min and Avg #####################
		cat $ResultFolder/ramtemp.log | tail -n +2 >  $ResultFolder/ram.txt.new && mv $ResultFolder/ram.txt.new $ResultFolder/ramtemp.log

		#echo "After Reading:" | cat $ResultFolder/ramtemp.log		
		while read line
		do
			IFS=' ' abc=($line)  #(cat $ResultFolder/ramtemp.log))
			echo "${abc[$MemUsecol]}" >> $ramsumfile
			echo "${abc[$MemperUsecol]}" >> $rampersumfile
		done < $ResultFolder/ramtemp.log
	
		#################Memory Used Calculation
		#Maximum RAM		
		ramsumvar1=$(awk '{ if ($1>max) {max=$1; line=$0} } END{print line}' $ramsumfile)
		ramsumvar=$server$','$ramsumvar1
		#Minimum RAM
		ramsumvar1=$(awk 'min=="" || $1 < min {min=$1; minline=$0}; END{ print minline}' $ramsumfile)
		ramsumvar=$ramsumvar','$ramsumvar1		
		#Average RAM
		ramsumvar1=$(awk '{s+=$1} END{print (s/(NR))}' $ramsumfile)
		ramsumvar=$ramsumvar$','$ramsumvar1','"kbmemused"

		################# Percentage Memory Used Calculation
		#Maximum RAM		
		rampersumvar1=$(awk '{ if ($1>max) {max=$1; line=$0} } END{print line}' $rampersumfile)
		rampersumvar=$server$','$rampersumvar1
		#Minimum RAM
		rampersumvar1=$(awk 'min=="" || $1 < min {min=$1; minline=$0}; END{ print minline}' $rampersumfile)
		rampersumvar=$rampersumvar','$rampersumvar1		
		#Average RAM
		rampersumvar1=$(awk '{s+=$1} END{print (s/(NR))}' $rampersumfile)
		rampersumvar=$rampersumvar$','$rampersumvar1','"%memused"

		###### Add Min, Max and Average values for a Server in the Summary file 
		echo $ramsumvar >> $RAMSUMFile
		echo $rampersumvar >> $RAMSUMFile
		#ramsumvar=""		

	elif [ "$1" = "$NWFILE" ]  
	then 
		########################################### NETWORK ###########################################
		######	sarSummary $NWFILE "IFACE" "eth0" "rxkB/s" "txkB/s"					#######
		###############################################################################################
			
	       # Files to store NW Columns data
	       nwtxkbfile=$ResultFolder/nwtxkb.log     	#txkB/s
	       nwrxkbfile=$ResultFolder/nwrxkb.log	#rxkB/s
              
	       # Create empty file
	       cp /dev/null $nwtxkbfile
       	cp /dev/null $nwrxkbfile              
		cp /dev/null $ResultFolder/nwtemp.log
        
		# Generate File with SAR Result row 
		cp /dev/null $nwtemp.log	
		cat $1 | tail -n +3 | head -n -2 >  $ResultFolder/nw.txt.new && mv $ResultFolder/nw.txt.new $ResultFolder/nwtemp.log # Delete top 2 amd bottom 1 line
		
		abc=()
		IFS=' ' abc=($(head -1 $ResultFolder/nwtemp.log))   ### Read the first line from file
		
		i=0
		IFASEcol=0
		txkBcol=0
		rxkBcol=0
		for ((i=0; i< ${#abc[@]}; i++))	#Read abc array and store column number of defined column names
		do			
			#Check column location
			if [ "${abc[$i]}" == "$2" ]  #IFACE
			then
				IFASEcol=$i				
			elif [ "${abc[$i]}" == "$5" ]  #txkb/s
			then
				txkBcol=$i				
			elif [ "${abc[$i]}" == "$4" ]  #rxkb/s
			then
				rxkBcol=$i					
			fi				
		done
		
		cat $ResultFolder/nwtemp.log | tail -n +2 >  $ResultFolder/nw.txt.new && mv $ResultFolder/nw.txt.new $ResultFolder/nwtemp.log		# Delete Header row
		while read line 			# Read txkb and rxkb value for the row having "IFASE = etho"
		do
			IFS=' ' abc=($line)  
			if [ "${abc[$IFASEcol]}" == "$3" ]  # check for IFASE Value is "eth0" then add txkb n rxkb value in one file 
			then
				echo "${abc[$txkBcol]}" >> $nwtxkbfile
				echo "${abc[$rxkBcol]}" >> $nwrxkbfile
			fi
		done < $ResultFolder/nwtemp.log

		############ Read line from NW file and calculate Max, Min and Avg #############333

		########## Network data Summary Calculation - txkb/s
		nwsum=0.0
		nwsum1=0.0
		nwrxkb=""
              nwrxkb1=0.0      
              nwtxkb=""
              nwtxkb1=0.0

		nwrxkb1=$(awk '{ if ($1>max) {max=$1; line=$0} } END{print line}' $nwrxkbfile)  #Minimum NW
		nwtxkb1=$(awk '{ if ($1>max) {max=$1; line=$0} } END{print line}' $nwtxkbfile)  
		#nwsum=$(echo $nwrxkb1 + $nwtxkb1 | bc) 	
		nwsum='expr $nwrxkb1 + $nwxkb1' | bc
		nwsumvar=$server$','$nwsum
	
		nwrxkb1=$(awk 'min=="" || $1 < min {min=$1; mintx=$0}; END{ print mintx}' $nwrxkbfile)
		nwtxkb1=$(awk 'min=="" || $1 < min {min=$1; mintx=$0}; END{ print mintx}' $nwtxkbfile)
		nwsum=$(echo $nwrxkb1 + $nwtxkb1 | bc)
		nwsumvar=$nwsumvar$','$nwsum
		
		nwrxkb1=$(awk '{s+=$1} END{print (s/(NR))}' $nwrxkbfile) #Average 
		nwtxkb1=$(awk '{s+=$1} END{print (s/(NR))}' $nwtxkbfile)	
		nwsum=$(echo $nwrxkb1 + $nwtxkb1 | bc)
		nwsumvar=$nwsumvar$','$nwsum
		
		###### Add Min, Max and Average values for a Server in the Summary file 
		echo $nwsumvar >> $NWSUMFile

	elif [ "$1" = "$DISKFILE1" ]  ################################ DISK1 Calculation ###############################3
	then 
		########################################### DISK1 #############################################
		###########					sarSummary $DISKFILE1 "tps" "rtps" "wtps"				###########
		###############################################################################################
	
		#### DISK1 related Code: Delete top 3 lines and bottom one line and add data in new file
		# Files to store DISK1 Columns data
		diskTpsfile=$ResultFolder/diskTpsfile.log
		diskrTpsfile=$ResultFolder/diskrTpsfile.log
		diskwTpsfile=$ResultFolder/diskwTpsfile.log
		disk1temp=$ResultFolder/disk1temp.log
		# Create empty file
		cp /dev/null $diskTpsfile
		cp /dev/null $diskrTpsfile
		cp /dev/null $diskwTpsfile
		
		diskTpsvar1=""
		#diskTpsvar=""		
		diskrTpsvar=""
		diskrTpsvar1=""
		diskwTpsvar=""
		diskwTpsvar1=""

		# Generate File with SAR Result row 
		
		cp /dev/null $disk1temp
		cat $1 | tail -n +3 | head -n -1 >  $ResultFolder/disk.txt.new && mv $ResultFolder/disk.txt.new $ResultFolder/disk1temp.log  # delete top 2 file n bottom 1 line

		abc=()		
		IFS=' ' abc=($(head -1  $ResultFolder/disk1temp.log))		
		i=0
		for ((i=0; i< ${#abc[@]}; i++))
		do			
			#Check column location
			if [ "${abc[$i]}" = "$2" ]  #TPS column name
			then
				DiskTpscol=$i
			elif [ "${abc[$i]}" = "$3" ]  #rTPS column name
			then
				DiskrTpscol=$i
			elif [ "${abc[$i]}" = "$4" ]  #wTPS column name
			then
				DiskwTpscol=$i			
			fi				
		done
		# Read line from NW file and calculate Max, Min and Avg #####################
		cat $ResultFolder/disk1temp.log | tail -n +2 >  $ResultFolder/disk1.txt.new && mv $ResultFolder/disk1.txt.new $ResultFolder/disk1temp.log

		#echo "After Reading:" | cat $ResultFolder/disk1temp.log		
		while read line
		do
			IFS=' ' abc=($line)  #(cat $ResultFolder/cputemp.log))
			#echo "Array: "${abc[@]}""		
			echo "${abc[$DiskTpscol]}" >> $diskTpsfile
			echo "${abc[$DiskrTpscol]}" >> $diskrTpsfile	
			echo "${abc[$DiskwTpscol]}" >> $diskwTpsfile			
		done < $ResultFolder/disk1temp.log
		
		########## DISK1 : Maximum TPS
		diskTpsvar1=$(awk '{ if ($1>max) {max=$1; line=$0} } END{print line}' $diskTpsfile)  #MAX CPU Utilization
		diskTpsvar=$server$','$diskTpsvar1

		diskTpsvar1=$(awk 'min=="" || $1 < min {min=$1; minline=$0}; END{ print minline}' $diskTpsfile)
		diskTpsvar=$diskTpsvar$','$diskTpsvar1
		
		diskTpsvar1=$(awk '{s+=$1} END{print s/(NR)}' $diskTpsfile)	#Average CPU Utilization
		diskTpsvar=$diskTpsvar$','$diskTpsvar1','"TPS"

		########## rTPS data

		diskrTpsvar1=$(awk '{ if ($1>max) {max=$1; line=$0} } END{print line}' $diskrTpsfile)  #Max
		diskrTpsvar=$server$','$diskrTpsvar1

		diskrTpsvar1=$(awk 'min=="" || $1 < min {min=$1; minline=$0}; END{ print minline}' $diskrTpsfile)  #Min
		diskrTpsvar=$diskrTpsvar$','$diskrTpsvar1

		diskrTpsvar1=$(awk '{s+=$1} END{print (s/(NR))}' $diskrTpsfile)   # Average
		diskrTpsvar=$diskrTpsvar$','$diskrTpsvar1','"rTPS"

		########## wTPS data

		diskwTpsvar1=$(awk '{ if ($1>max) {max=$1; line=$0} } END{print line}' $diskwTpsfile)  #Max
		diskwTpsvar=$server$','$diskwTpsvar1

		diskwTpsvar1=$(awk 'min=="" || $1 < min {min=$1; minline=$0}; END{ print minline}' $diskwTpsfile)  #Min
		diskwTpsvar=$diskwTpsvar$','$diskwTpsvar1

		diskwTpsvar1=$(awk '{s+=$1} END{print (s/(NR))}' $diskwTpsfile)   # Average
		diskwTpsvar=$diskwTpsvar$','$diskwTpsvar1','"wTPS"		
		
		###### Add Min, Max and Average values for a Server in the Summary file 
		echo $diskTpsvar >> $DISK1SUMFile
		echo $diskrTpsvar >> $DISK1SUMFile
		echo $diskwTpsvar >> $DISK1SUMFile		
	fi
	#return 0
}
########################### END of SUMMARY CALCULATION FUNCTION ###########################
###########################################################################################

# Verify HOST File exists 
if [ -z "$REMOTE_HOSTS" ] ; then
	echo "Remote Hosts not Defined...Existing the Script."
	exit 0
else 	# the property REMOTE_HOSTS is set so we wil use this list of predefined hosts 
       hosts=(`echo $REMOTE_HOSTS | tr "," "\n" | tr -d ' '`)	
        instance_count=${#hosts[@]}
	

	########## For Password Less Login on Defined Host File ###############
	if [ $PASSWDLESS = "true" ] ; then
		ssh-keygen -t rsa
		for server in ${hosts[@]} ################Provide Password for each command
		do
			ssh $User@$server mkdir -p .ssh
			cat $Path/.ssh/id_rsa.pub | $User@$server 'cat >> .ssh/authorized_keys' ##cat .ssh/id_rsa.pub | $User@$server 'cat >> .ssh/authorized_keys'
			ssh $User@$server "chmod 700 $Path/.ssh; chmod 640 $Path/.ssh/authorized_keys"
		done
		echo "Done... Password less login for machine IPs defined in $HOSTFILE "

  	########## To Generate SAR Summary Report from already existing SAR Result ###############
	elif [ $SARREPORT_ONLY = "true" ] ; then 
		#if [ -f $RESULTFILE ]; then 
		if [ -n "$SAR_FILENAME" ] ; then  # Returns true if the string is not null
			sarfile=(`echo $SAR_FILENAME | tr "," "\n" | tr -d ' '`)

			printf "SAR Result File found, generating SAR Summary Report \n"
			# Create Summary File			
			for FileName in ${sarfile[@]}
			do		
				# Variables to Create CPU Summary File
					CPUSUMFile=$ResultFolder/${FileName}_SummaryCPU.csv
					echo "IPAddress,Maximum,Minimum,Average,ColumnName" >> $CPUSUMFile
				# Variables to Create RAM Summary File
					RAMSUMFile=$ResultFolder/${FileName}_SummaryRAM.csv
					echo "IPAddress,Maximum,Minimum,Average,ColumnName" >> $RAMSUMFile
				# Variables to Create NW Summary File
					NWSUMFile=$ResultFolder/${FileName}_SummaryNW.csv
					echo "IPAddress,Maximum,Minimum,Average" >> $NWSUMFile		
				# Variables to Create DISK1 Summary File
					DISK1SUMFile=$ResultFolder/${FileName}_SummaryDISK1.csv
					echo "IPAddress,Maximum,Minimum,Average,ColumnName" >> $DISK1SUMFile	
			done

			#Read HostFile and Generate Summary
			for server in ${hosts[@]}
			do
			  	# Check File exists in Folder if yes then extract NAME and check ServerName file exists
				printf "SAR Summary for:${server}\n"
				for FileName in ${sarfile[@]}
				do		
					NWFILE=$ResultFolder/${FileName}_${server}_NW.log
					CPUFILE=$ResultFolder/${FileName}_${server}_CPU.log
					RAMFILE=$ResultFolder/${FileName}_${server}_RAM.log
					DISKFILE1=$ResultFolder/${FileName}_${server}_DISK1.log
					DISKFILE2=$ResultFolder/${FileName}_${server}_DISK2.log			

					#######CPU Report
					if [ -f $CPUFILE ]
					then
						CPUSUMFile=$ResultFolder/${FileName}_SummaryCPU.csv				
						sarSummary $CPUFILE "%user" "%system" "%iowait" "%idle"	# For CPU Summary
					else
						printf "SAR CPU report $CPUFILE for ${server} Not Exists \n "
					fi	
					#######Network Report
					if [ -f $NWFILE ]
					then
						NWSUMFile=$ResultFolder/${FileName}_SummaryNW.csv
						sarSummary $NWFILE "IFACE" "eth0" "rxkB/s" "txkB/s"	# For Network Summary 				
					else
						printf "SAR Network report $NWFILE for ${server} Not Exists \n "
					fi	
					
					#######RAM Report
					if [ -f $RAMFILE ]
					then
						RAMSUMFile=$ResultFolder/${FileName}_SummaryRAM.csv
						sarSummary $RAMFILE "kbmemused" "%memused"	# For RAM Summary 
					else
						printf "SAR RAM report $RAMFILE for ${server} Not Exists \n"
					fi
					#######DISK1 Report
					if [ -f $DISKFILE1 ]
					then
						DISK1SUMFile=$ResultFolder/${FileName}_SummaryDISK1.csv
						sarSummary $DISKFILE1 "tps" "rtps" "wtps" # For DISK Summary
					else
						printf "SAR DISK1 report $DISKFILE1 for ${server} Not Exists \n"
					fi
				done
			done
			echo "SAR Summary Report generated for SAR reports defined in $SAR_FILENAME $'\n'"
			#exit 0
		else
			printf "File \"$SAR_FILENAME\" not found \n"
			exit 0
		fi
	############# Install Sysstat on Host Servers defined in HOSTFILE ############# 
	elif [ $SYSSTATE_INSTALL = "true" ] ; then
		DATETIME=$(date "+%s")
		
		# Check if remote hosts are up
		# for host in ${hosts[@]} ; do
		# echo "Host Name $host "
	        # if [ ! "$(ssh -q -q \
	           #  -o StrictHostKeyChecking=no \
	           #  -o "BatchMode=yes" \
	           #  -o "ConnectTimeout 15" \
	           #  -i $PEM_PATH/$PEM_FILE \
	           #  $User@$host echo up 2>&1)" == "up" ] ; then
	           #  echo "Host $host is not responding, script exiting..."
	           #  echo
	           #  exit
	        # fi
		# done
		
		# Install SYSSTAT
		for server in ${hosts[@]} 
		do
			echo "Sysstate Installation started on Server $server \n"								
			if [ $HOSTOS = "Ubuntu" ] 
			then
				scp -q -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no \
					-i $PEM_PATH/$PEM_FILE $SARPath/Install.sh $User@$server:$Path
						# > $Path/$DATETIME-$server-scpinstall.out				  

				echo "Install.sh File Copied to $server...." 

				(ssh -nq -o StrictHostKeyChecking=no \
					 -i $PEM_PATH/$PEM_FILE -t -t $User@$server "$Path/Install.sh $Path $SYSSTAT_VERSION $HOSTOS") & sleep 5
					 # > $Path/$DATETIME-$server-Ubuntusysstateinstall.out) &

				echo "*************************************************************************" 

				
			elif [ $HOSTOS = "CentOS" ] 
			then
				scp -q -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no \
						 -i $PEM_PATH/$PEM_FILE $User@$server $SARPath/Install.sh $User@$server:$Path 
	                                     # > $Path/$DATETIME-$server-CentosScp.out

				echo "Install.sh File Copied to $server... "
				(ssh -nq -tt -o StrictHostKeyChecking=no \
					 -i $PEM_PATH/$PEM_FILE $User@$server "$Path/Install.sh $Path $SYSSTAT_VERSION $HOSTOS") &
					# > $Path/$DATETIME-$server-CentOSsysstateInstall.out) &
				
				#-t flag to force a tty to be allocated, -q Quite to suppres error 
				sleep 5
			fi
		done 
	else
		#############################SAR Execution + Summary Report ##############################
		###########################################################################################
		# Check if remote hosts are up
		# for host in ${hosts[@]} ; do
		
	       # if [ ! "$(ssh -q -q \
	            # -o StrictHostKeyChecking=no \
	            # -o "BatchMode=yes" \
	            # -o "ConnectTimeout 15" \
	            # -i $PEM_PATH/$PEM_FILE \
	            # $USER@$host echo up 2>&1)" == "up" ] ; then
	            # echo "Host $host is not responding, script exiting..."
	            # echo
	            # exit
	       # fi
		# done
	
		if [ -z "${FileName}" ] ; then # Check if Filename is passed to the Script. 
			echo "SAR file name not defined... \n"
			exit 0
		fi		

		printf "Preparing to start SAR utility for $Time seconds with counter collection at every $Interval seconds \n"
		if [ $HOSTOS = "Ubuntu" ] ; then
			Count=`expr $Time / $Interval`		# For ec2-user Machine: Count of time SAR to be executed on Host machines. It is Total duration \ Interval. 
		elif [ $HOSTOS = "CentOS" ] ; then
			declare -i Count=$Time/$Interval	# For CentOS Machine: Count of time SAR to be executed on Host machines. It is Total duration \ Interval. 	
		else
			echo "Client Machines Operating System name is not defined.... "
			exit 0
		fi
		
		# Run SAR  on Host machines as per defined time interval
		for server in ${hosts[@]}
		do
			printf "Starting:${server}\n"
			ssh ${User}@${server} -i  $PEM_PATH/$PEM_FILE sar -n DEV -r -u -b -d -p -o $Path/${FileName}_${server}.log $Interval > /dev/null &
		done
		echo 
			printf "SAR Execution started on all server. Waiting $Time seconds to complete execution \n"
			sleep $Time
		
		# Variables to Create CPU Summary File
		CPUSUMFile=$ResultFolder/${FileName}_SummaryCPU.csv
		echo "IPAddress,Maximum,Minimum,Average,ColumnName" >> $CPUSUMFile

		# Variables to Create RAM Summary File
		RAMSUMFile=$ResultFolder/${FileName}_SummaryRAM.csv
		echo "IPAddress,Maximum,Minimum,Average,ColumnName" >> $RAMSUMFile
		#ramsumvar="IP_Address,Maximum,Minimum,Average"

		# Variables to Create NW Summary File
		NWSUMFile=$ResultFolder/${FileName}_SummaryNW.csv
		echo "IPAddress,Maximum,Minimum,Average" >> $NWSUMFile
		#nwsumvar="IP_Address,Maximum,Minimum,Average"

		# Variables to Create DISK1 Summary File
		DISK1SUMFile=$ResultFolder/${FileName}_SummaryDISK1.csv
		echo "IPAddress,Maximum,Minimum,Average,ColumnName" >> $DISK1SUMFile
		#diskTpsvar="IP_Address,Maximum,Minimum,Average,Column_Name"

		
		for server in ${hosts[@]}
		do
				LOGFILE=$Path/${FileName}_${server}.log
				echo "first log"
				scp -q -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no \
                    -i "$PEM_PATH/$PEM_FILE" \
                    -P $REMOTE_PORT \
                    $USER@$server:$LOGFILE $ResultFolder 
#				scp -i $PEM_PATH/$PEM_FILE ${User}@${server}:$LOGFILE $ResultFolder

				LOG=$ResultFolder/${FileName}_${server}.log		

				if [ -f $LOG ]; then
					NWFILE=$ResultFolder/${FileName}_${server}_NW.log
					CPUFILE=$ResultFolder/${FileName}_${server}_CPU.log
					RAMFILE=$ResultFolder/${FileName}_${server}_RAM.log
					DISKFILE1=$ResultFolder/${FileName}_${server}_DISK1.log
					DISKFILE2=$ResultFolder/${FileName}_${server}_DISK2.log

					sar -n DEV -f $LOG > $NWFILE
					sar -u -f $LOG > $CPUFILE
					sar -r -f $LOG > $RAMFILE
					sar -b -f $LOG > $DISKFILE1
					sar -d -f $LOG > $DISKFILE2						
								
				####################### Call Summary Function ##########################################
					sarSummary $CPUFILE "%user" "%system" "%iowait" "%idle" # For CPU Summary
					sarSummary $RAMFILE "kbmemused" "%memused"		# For RAM Summary 
					sarSummary $NWFILE "IFACE" "eth0" "rxkB/s" "txkB/s"	# For Network Summary 
					sarSummary $DISKFILE1 "tps" "rtps" "wtps"			# For DISK Summary
				fi
		done
	fi

    fi
##################################################################################
# Delete all Temp Files created to generate Summary report
sudo rm -f $ResultFolder/ramtemp.log
sudo rm -f $ResultFolder/ramsumfile.log
sudo rm -f $ResultFolder/rampersumfile.log
sudo rm -f $ResultFolder/nwtxkb.log
sudo rm -f $ResultFolder/nwtemp.log
sudo rm -f $ResultFolder/nwrxkb.log
sudo rm -f $ResultFolder/diskwTpsfile.log
sudo rm -f $ResultFolder/diskTpsfile.log
sudo rm -f $ResultFolder/diskrTpsfile.log
sudo rm -f $ResultFolder/disk1temp.log
sudo rm -f $ResultFolder/cupiowait.log
sudo rm -f $ResultFolder/cpuuser.log
sudo rm -f $ResultFolder/cputemp.log
sudo rm -f $ResultFolder/cpusystem.log
sudo rm -f $ResultFolder/cpuidle.log

exit 0